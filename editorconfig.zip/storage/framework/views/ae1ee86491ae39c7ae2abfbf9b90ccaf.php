<?php $__env->startSection('section'); ?>
    <div id="content-wrapper" class="d-flex flex-column">
        <!-- Main Content -->
        <div id="content">
            <!-- Topbar -->
            <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Topbar -->
            <!-- Begin Page Content -->
            <div class="container-fluid">
                <!-- Page Heading -->
                <h1 class="h3 mb-2 text-gray-800">Equipments</h1>
                <!-- DataTales Example -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Equipments List</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <div id="dataTable_wrapper" class="dataTables_wrapper dt-bootstrap4">
                                <div class="row mb-5">
                                    <form action="<?php echo e(route('equipments.update', $equipment->id)); ?>" method="POST"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <?php echo $__env->make('equipments.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <button type="submit" class="btn btn-primary">Update Equipment</button>
                                    </form>
                                </div>
                            </div>
                            <?php echo $__env->make('equipments.calender_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div id="table-content">
                                <table class="table table-bordered dataTable calenderTable" width="100%" cellspacing="0"
                                    role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                                    <thead>
                                        <tr role="row">
                                            <th class="sorting sorting_asc" tabindex="0" aria-controls="dataTable"
                                                rowspan="1" colspan="1" aria-sort="ascending"
                                                aria-label="Name: activate to sort column descending">
                                                Date</th>
                                            <th class="sorting sorting_asc" tabindex="0" aria-controls="dataTable"
                                                rowspan="1" colspan="1" aria-sort="ascending"
                                                aria-label="Name: activate to sort column descending">
                                                Day</th>
                                            <th class="sorting sorting_asc" tabindex="0" aria-controls="dataTable"
                                                rowspan="1" colspan="1" aria-sort="ascending"
                                                aria-label="Name: activate to sort column descending">
                                                Timings</th>
                                            <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1"
                                                colspan="1" aria-label="Position: activate to sort column ascending">
                                                Status</th>
                                            <th class="sorting" tabindex="0" aria-controls="dataTable" rowspan="1"
                                                colspan="1" aria-label="Age: activate to sort column ascending">Action
                                            </th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <p></p>
                                        <?php if(isset($equipment->records)): ?>
                                            <?php $__empty_1 = true; $__currentLoopData = $equipment->records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr class="odd">
                                                    <td class="sorting_1"><?php echo e($record->date); ?></td>
                                                    <td><?php echo e($record->day); ?></td>
                                                    <td><?php echo e($record->timings); ?></td>
                                                    <td><?php echo e($record->status); ?></td>
                                                    <td><a href="#" class="delete-record"
                                                            data-id="<?php echo e($record->id); ?>">Delete</a></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            No Calender Added!
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- End of Main Content -->
        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright &copy; Your Website 2021</span>
                </div>
            </div>
        </footer>
        <!-- End of Footer -->

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            var today = new Date().toISOString().split('T')[0];
            $('#datePicker').attr('min', today);
            $('#incharge_phone').on('input', function() {
                this.value = this.value.replace(/[^0-9]/g, '');
            });
            $('#AddContent').click(function(event) {
                event.preventDefault(); // Prevent the default action
                var day = $('#day').val();
                var timings = $('#timings').val();
                var date = $('#datePicker').val();
                var equipment_id = <?php echo e($equipment->id); ?>;
                var isValid = true;
                $('.day-error').text('');
                if (day === "" || day === null) {
                    $('.day-error').text('Please select a day.');
                    isValid = false;
                }
                $('.timings-error').text('');
                if (timings === "" || timings === null) {
                    $('.timings-error').text('Please select a Timing.');
                    isValid = false;
                }
                $('.date-error').text('');
                if (date === "" || date === null) {
                    $('.date-error').text('Please choose a Date.');
                    isValid = false;
                }
                var status = $('#status_calender').val();
                $('.status-error').text('');
                if (status === "" || status === null) {
                    $('.status-error').text('Please select a status.');
                    isValid = false;
                }
                if (isValid) {
                    $.ajax({
                        url: '<?php echo e(route('add_calender')); ?>', // Replace with your route
                        type: 'POST',
                        data: {
                            status: status,
                            equipment_id: equipment_id,
                            day: day,
                            date: date,
                            timings: timings,
                            _token: '<?php echo e(csrf_token()); ?>',
                        },
                        success: function(response) {
                            $('#table-content').load(window.location.href +
                                ' #table-content > *');
                        },
                        error: function(response) {
                            alert('Error occurred while submitting the form');
                        }
                    });
                }
            });
            // Handle deletion of records
            $(document).on('click', '.delete-record', function(event) {
                event.preventDefault();
                var deleteButton = $(this);
                deleteButton.prop('disabled', true);
                var recordId = deleteButton.data('id');
                $.ajax({
                    url: '<?php echo e(url('calender/delete')); ?>/' + recordId,
                    type: 'GET',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                    },
                    success: function(response) {
                        $('#table-content').load(window.location.href + ' #table-content > *');
                        deleteButton.prop('disabled', false);
                    },
                    error: function(response) {
                        alert('Error occurred while deleting the record');
                        deleteButton.prop('disabled', false);
                    }
                });
            });


        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('Dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u416014838/domains/estihomebidder.com/public_html/resources/views/equipments/edit.blade.php ENDPATH**/ ?>