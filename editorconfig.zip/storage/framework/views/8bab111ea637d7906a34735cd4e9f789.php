 <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav metismenu" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element">
                                                            <div style="position:relative; width:50px">
                                    <img alt="image" class="rounded-circle" src="https://iicbooking.iitr.ac.in/admin_asset/img/profile_small.jpg" />
                                    <span class="pro-pic" title="change profile" onclick="changeprofile()"></span>
                                </div>
                                                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="block m-t-xs font-bold"> <?php echo e(Auth::user()->name); ?></span>
                                                                    <span class="text-muted text-xs block">Role: IITR-Student</span>
                                    <span class="text-muted text-xs block">Student ID: 19920011</span>
                                   <!-- <span class="text-muted text-xs block">Guide: Kaushik Pal</span>-->
                                                            </a>
                        </div>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span></a>
                    </li>
                                            <li>
                            <a href="#"><i class="fa fa-th-large"></i> <span class="nav-label">Book Equipment</span></a>
                        </li>
                                                <li>
                            <a href="#"><i class="fa fa-th-large"></i> <span class="nav-label">View Booking</span></a>
                        </li>
                       
                                                            </ul>
            </div>
        </nav>
        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header">
                        <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
                    </div>
                    <ul class="nav navbar-top-links navbar-right">
                        <li>
                            <a href="#">
                                <i class="fa fa-user"></i> My Account
                            </a>
                        </li>
                        <li>
                             <a  onclick="event.preventDefault();  document.getElementById('logout-form').submit();" href="<?php echo e(route('logout')); ?>">Logout</a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                            
                        </li>
                    </ul>
                </nav>
            </div>
            <!-- end header -->
            <form role="form" enctype="multipart/form-data" name="profile_image" method="post" id="profile_form" action="#">
                <input type="file" id="profile_image" name="profile_pic" hidden accept="image/x-png,image/gif,image/jpeg">
            </form>
            <script>
                function changeprofile() {
                    $('#profile_image').trigger('click', true);
                }

                $('#profile_image').change(function() {
                    $('#profile_form').submit();
                });
            </script><style>
    .alert {margin-bottom: 0 !important;}
</style><?php /**PATH /home/u416014838/domains/estihomebidder.com/public_html/resources/views/user/layout/sidebar.blade.php ENDPATH**/ ?>