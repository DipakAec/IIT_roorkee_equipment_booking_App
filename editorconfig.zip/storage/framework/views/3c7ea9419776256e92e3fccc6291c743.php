
<div class="row">
    <div class="col-md-6">
        <div class="row">
            <div class="mb-3">
                <label for="image" class="form-label">Equipment Image</label>
                <input type="file" name="image" class="form-control" id="image"
                    value="<?php echo e(old('name', $equipment->image ?? '')); ?>">
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="row">
            <div class="mb-3 col-md-6">
                <label for="name" class="form-label">Name</label>
                <input type="text" name="name" class="form-control" id="name"
                    value="<?php echo e(old('name', $equipment->name ?? '')); ?>">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 col-md-6">
                <label for="incharge_name" class="form-label">Incharge Name</label>
                <input type="text" name="incharge_name" class="form-control" id="incharge_name"
                    value="<?php echo e(old('incharge_name', $equipment->incharge_name ?? '')); ?>" required>
                <?php $__errorArgs = ['incharge_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="row">
            <div class="mb-3 col-md-6">
                <label for="incharge_email" class="form-label">Incharge Email</label>
                <input type="text" name="incharge_email" class="form-control" id="incharge_email"
                    value="<?php echo e(old('incharge_email', $equipment->incharge_email ?? '')); ?>" required>
                <?php $__errorArgs = ['incharge_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 col-md-6">
                <label for="incharge_phone" class="form-label">Incharge Phone</label>
                <input type="text" name="incharge_phone" class="form-control" id="incharge_phone"
                    value="<?php echo e(old('incharge_phone', $equipment->incharge_phone ?? '')); ?>" required>
                    <small class="form-text text-muted">Please enter only numbers.</small>
                <?php $__errorArgs = ['incharge_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="row">
            <div class="mb-3 col-md-6">
                <label for="number_of_slots" class="form-label">Number of Slots</label>
                <input type="number" name="number_of_slots" class="form-control" id="number_of_slots"
                    value="<?php echo e(old('number_of_slots', $equipment->number_of_slots ?? '')); ?>" required>
                <?php $__errorArgs = ['number_of_slots'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 col-md-6">
                <label for="status" class="form-label">Status</label>
                <select name="status" class="form-select" id="status" aria-label="Default select example" required>
                    <option value="" disabled>Select the status</option>
                    <option value="1" <?php echo e(old('status', $equipment->status ?? '') == '1' ? 'selected' : ''); ?>>Active
                    </option>
                    <option value="0" <?php echo e(old('status', $equipment->status ?? '') == '0' ? 'selected' : ''); ?>>Deactive
                    </option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="row">
            <div class="mb-3 col-md-6">
                <label for="sample_requirements" class="form-label">Sample Requirements</label>
                <input type="text" name="sample_requirements" class="form-control" id="sample_requirements"
                    value="<?php echo e(old('sample_requirements', $equipment->sample_requirements ?? '')); ?>" required>
                <?php $__errorArgs = ['sample_requirements'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 col-md-6">
                <label for="additional_accessories" class="form-label">Additional Accessories</label>
                <input type="text" name="additional_accessories" class="form-control" id="additional_accessories"
                    value="<?php echo e(old('additional_accessories', $equipment->additional_accessories ?? '')); ?>" required>
                <?php $__errorArgs = ['additional_accessories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="row">
            <div class="mb-3">
                <label for="location" class="form-label">Location</label>
                <input type="text" name="location" class="form-control" id="location"
                    value="<?php echo e(old('location', $equipment->location ?? '')); ?>" required>
                <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <?php if( isset($equipment->image) && $equipment->image != null): ?>
        <img style="max-height:500px;object-size:cover;" src="<?php echo e(asset('website/' . $equipment->image)); ?>" alt="">
        <?php else: ?>
        <img style="max-height:250px;width:fit-content;" src="<?php echo e(asset('assets/img/undraw_posting_photo.svg')); ?>" alt="">
        <?php endif; ?>
    </div>
</div>

<?php /**PATH /home/u416014838/domains/estihomebidder.com/public_html/resources/views/equipments/form.blade.php ENDPATH**/ ?>