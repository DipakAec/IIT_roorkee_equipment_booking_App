<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>IITR-EMS</title>

    <link href="https://iicbooking.iitr.ac.in/admin_asset/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://iicbooking.iitr.ac.in/admin_asset/font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="https://iicbooking.iitr.ac.in/admin_asset/css/animate.css" rel="stylesheet">
    <link href="https://iicbooking.iitr.ac.in/admin_asset/css/style.css" rel="stylesheet">

    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/jquery-3.1.1.min.js"></script>

    <link href="https://iicbooking.iitr.ac.in/admin_asset/css/plugins/dataTables/datatables.min.css" rel="stylesheet">

    <!-- switcher -->
    <link href="https://iicbooking.iitr.ac.in/admin_asset/css/plugins/switchery/switchery.css" rel="stylesheet">


    <!-- Toastr style -->
    <link href="https://iicbooking.iitr.ac.in/admin_asset/css/plugins/toastr/toastr.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@9/dist/sweetalert2.min.css" id="theme-styles">

    <!--dropzone css-->
    <link href="https://iicbooking.iitr.ac.in/admin_asset/css/plugins/dropzone/dropzone.css" rel="stylesheet">
    <!--checkbox css-->
    <link
        href="https://iicbooking.iitr.ac.in/admin_asset/css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css"
        rel="stylesheet">
    <!-- ajax datatable -->
    <script type="text/javascript" src="https://iicbooking.iitr.ac.in/admin_asset/DataTables/datatables.min.js">
    </script>

    <script>
        var base_url = "https://iicbooking.iitr.ac.in/";
    </script>
</head>

<body>
    <div class="container">
        <style type="text/css">
            .hide {
                display: none;
            }

            .show {
                display: block;
            }

            .container {
                padding-top: 50px;
                margin: auto;
            }
        </style>
        <a href="https://estihomebidder.com/" style="color: #fff">
            <h3>Home</h3>
        </a>
        <style>
            span.required {
                color: red !important;
            }
        </style>
        <div class="row">
            <div class="col-md-12">
                <div class="card ">
                    <div class="wrapper wrapper-content animated fadeIn">
                        <form role="form" enctype="multipart/form-data" name="user_form" id="userForm" method="post">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>User Type</label>
                                        <select class="form-control" name="user_type_id" id="user_type">
                                            <option value="2"> IITR-Student</option>
                                            <option value="4"> EXT Educational Institute</option>
                                            <option value="5"> Govt. R&D Center</option>
                                            <option value="6"> Industry</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="name_label">Student Name <span class="required">*</span></label>
                                        <input type="text" placeholder="Enter Name" class="form-control" name="name"
                                            value="" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="email_label">Student Email <span class="required">*</span></label>
                                        <input type="email" placeholder="Enter Email" class="form-control" name="email"
                                            value="" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Password <span class="required">*</span></label>
                                        <input type="password" placeholder="Enter Password" class="form-control"
                                            name="pass" value="" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Student Enrollment Number <span class="required">*</span></label>
                                        <input type="text" placeholder="Enter enrollment number" class="form-control"
                                            name="emp_id" value="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Student Department <span class="required">*</span></label>
                                        <select class="form-control" name="dept" required>
                                            <option>--select--</option>
                                            <option
                                                value="AcSIR Materials Science and Sensor Applications CSIR-CSIO Chandigarh">
                                                AcSIR Materials Science and Sensor Applications CSIR-CSIO Chandigarh
                                            </option>
                                            <option value="Advanced Materials Technology Department">Advanced Materials
                                                Technology Department</option>
                                            <option value="Advanced School of Chemical Sciences">Advanced School of
                                                Chemical Sciences</option>
                                            <option value="Amity Institute of Nanotechnology">Amity Institute of
                                                Nanotechnology</option>
                                            <option value="Amity Institute of Pharmacy">Amity Institute of Pharmacy
                                            </option>
                                            <option value="Amrita Center for Nanosciences">Amrita Center for
                                                Nanosciences</option>
                                            <option value="API Analytical">API Analytical</option>
                                            <option value="Applied Chemistry">Applied Chemistry</option>
                                            <option value="Applied Science and Engineering">Applied Science and
                                                Engineering</option>
                                            <option value="Applied Sciences">Applied Sciences</option>
                                            <option value="Applied Sciences (Physics)">Applied Sciences (Physics)
                                            </option>
                                            <option value="Applied Sciences Department">Applied Sciences Department
                                            </option>
                                            <option value="Archaeological Survey of India">Archaeological Survey of
                                                India</option>
                                            <option value="Architecture and Planning">Architecture and Planning</option>
                                            <option value="AS & EC Division">AS & EC Division</option>
                                            <option
                                                value="Atomic Layer Deposition Material Synthesis Lab New Chemistry Unit JNCASR">
                                                Atomic Layer Deposition Material Synthesis Lab New Chemistry Unit JNCASR
                                            </option>
                                            <option value="babaji charan sahoo">babaji charan sahoo</option>
                                            <option value="Bio-product Chemistry Department">Bio-product Chemistry
                                                Department</option>
                                            <option value="biosc">biosc</option>
                                            <option value="Bioscienc">Bioscienc</option>
                                            <option value="Biotechnology">Biotechnology</option>
                                            <option value="Botany">Botany</option>
                                            <option value="Bralco Advanced Materials">Bralco Advanced Materials</option>
                                            <option
                                                value="Bralco Advanced Materials 03 -66 81 Ayer Rajah Crescent Singapore">
                                                Bralco Advanced Materials 03 -66 81 Ayer Rajah Crescent Singapore
                                            </option>
                                            <option value="BTKIT DWARAHAT">BTKIT DWARAHAT</option>
                                            <option value="CARE Department School of Interdisciplinary Research">CARE
                                                Department School of Interdisciplinary Research</option>
                                            <option value="center">center</option>
                                            <option value="Center for Nanoscience & Nanotechnology">Center for
                                                Nanoscience & Nanotechnology</option>
                                            <option value="Center for Nanoscience and Technology">Center for Nanoscience
                                                and Technology</option>
                                            <option value="Center for Rural Development">Center for Rural Development
                                            </option>
                                            <option value="Centre for Biochemistry">Centre for Biochemistry</option>
                                            <option value="Centre for Biomaterials Cellular and Molecular theranostics">
                                                Centre for Biomaterials Cellular and Molecular theranostics</option>
                                            <option value="Centre for Materials Science & Nano Technology">Centre for
                                                Materials Science & Nano Technology</option>
                                            <option value="Centre for Materials Science and Nanotechnology">Centre for
                                                Materials Science and Nanotechnology</option>
                                            <option
                                                value="Centre for Nano and Soft Matter Sciences (CeNS) Arkavathi  Campus Bengaluru">
                                                Centre for Nano and Soft Matter Sciences (CeNS) Arkavathi Campus
                                                Bengaluru</option>
                                            <option value="Centre for Nano Material Sciences">Centre for Nano Material
                                                Sciences</option>
                                            <option value="Centre for Nanoscience & Genomics">Centre for Nanoscience &
                                                Genomics</option>
                                            <option value="Centre for Nanoscience & Nanotechnology">Centre for
                                                Nanoscience & Nanotechnology</option>
                                            <option value="Centre for Nanotechnology Research">Centre for Nanotechnology
                                                Research</option>
                                            <option value="CENTRE FOR PHOTONICS AND QUANTUM COMMUNICATION TECHNOLOGY">
                                                CENTRE FOR PHOTONICS AND QUANTUM COMMUNICATION TECHNOLOGY</option>
                                            <option value="Centre for Transportation Systems (CTRANS)">Centre for
                                                Transportation Systems (CTRANS)</option>
                                            <option
                                                value="Centre of Excellence in Disaster Mitigation & Management (CoEDMM)">
                                                Centre of Excellence in Disaster Mitigation & Management (CoEDMM)
                                            </option>
                                            <option value="Centre of Food Technology">Centre of Food Technology</option>
                                            <option value="Centre of Nanotechnology">Centre of Nanotechnology</option>
                                            <option value="che">che</option>
                                            <option value="Chemical Biology Unit">Chemical Biology Unit</option>
                                            <option
                                                value="Chemical Biology Unit Institute of Nanoscience and Technology SAS Nagar Punjab">
                                                Chemical Biology Unit Institute of Nanoscience and Technology SAS Nagar
                                                Punjab</option>
                                            <option value="Chemical Engineering">Chemical Engineering</option>
                                            <option value="Chemical Engineering & Physical Sciences">Chemical
                                                Engineering & Physical Sciences</option>
                                            <option value="Chemical Sciences">Chemical Sciences</option>
                                            <option value="Chemical Technology Department">Chemical Technology
                                                Department</option>
                                            <option value="Chemistry">Chemistry</option>
                                            <option value="Chemistry Department">Chemistry Department</option>
                                            <option
                                                value="Chemistry Department The M.S. University of Baroda Vadodara Gujarat">
                                                Chemistry Department The M.S. University of Baroda Vadodara Gujarat
                                            </option>
                                            <option
                                                value="Chemistry Dept National Institute of Science and Technology Odisha">
                                                Chemistry Dept National Institute of Science and Technology Odisha
                                            </option>
                                            <option value="Chemistry Division BARC Trombay Mumbai">Chemistry Division
                                                BARC Trombay Mumbai</option>
                                            <option value="Chemistry The M.S">Chemistry The M.S</option>
                                            <option value="Chemistry The M.S. University of Baroda Vadodara Gujarat">
                                                Chemistry The M.S. University of Baroda Vadodara Gujarat</option>
                                            <option value="CIPET:SARP-LARPM Bhubaneswar Odisha">CIPET:SARP-LARPM
                                                Bhubaneswar Odisha</option>
                                            <option value="Civil Engineering">Civil Engineering</option>
                                            <option value="CNSNT ITER  SOS university Bhubaneshwar Odisha">CNSNT ITER
                                                SOS university Bhubaneshwar Odisha</option>
                                            <option
                                                value="CNSNT ITER Shiksha O Anusandhan University Bhubaneswar Odisha">
                                                CNSNT ITER Shiksha O Anusandhan University Bhubaneswar Odisha</option>
                                            <option value="College of Basic Sciences & Humanities">College of Basic
                                                Sciences & Humanities</option>
                                            <option value="College of Science">College of Science</option>
                                            <option value="Computer Science and Engineering">Computer Science and
                                                Engineering</option>
                                            <option value="Conservative Dentistry & Endodontics">Conservative Dentistry
                                                & Endodontics</option>
                                            <option value="CSIR IIP Dehradun">CSIR IIP Dehradun</option>
                                            <option value="CSIR IMTECH Chandigarh">CSIR IMTECH Chandigarh</option>
                                            <option
                                                value="CSIR Institute of Himalayan Bioresource Technology Palampur H.P.">
                                                CSIR Institute of Himalayan Bioresource Technology Palampur H.P.
                                            </option>
                                            <option value="CSIR National Physical Laboratory New Delhi">CSIR National
                                                Physical Laboratory New Delhi</option>
                                            <option
                                                value="CSIR-National Metallurgical Laboratory Analytical & Applied Chemistry Division Jamshedpur">
                                                CSIR-National Metallurgical Laboratory Analytical & Applied Chemistry
                                                Division Jamshedpur</option>
                                            <option value="DEEKSHA RANI">DEEKSHA RANI</option>
                                            <option value="Departm">Departm</option>
                                            <option value="Department for Environmental Science & Technology">Department
                                                for Environmental Science & Technology</option>
                                            <option value="Department of  Civil Engineering">Department of Civil
                                                Engineering</option>
                                            <option value="Department of Agronomy">Department of Agronomy</option>
                                            <option value="Department of Analytical Chemistry">Department of Analytical
                                                Chemistry</option>
                                            <option value="Department of Applied Chemistry">Department of Applied
                                                Chemistry</option>
                                            <option value="Department of Applied Mechanics">Department of Applied
                                                Mechanics</option>
                                            <option value="Department of Applied Science & Humanities">Department of
                                                Applied Science & Humanities</option>
                                            <option
                                                value="Department of Applied Sciences and Humanities NIAMT-NIFFT Ranchi">
                                                Department of Applied Sciences and Humanities NIAMT-NIFFT Ranchi
                                            </option>
                                            <option value="Department of Bio-Technology">Department of Bio-Technology
                                            </option>
                                            <option value="Department of Biosciences and Bioengineering">Department of
                                                Biosciences and Bioengineering</option>
                                            <option value="Department of Biotechnology">Department of Biotechnology
                                            </option>
                                            <option value="Department of Biotechnology and Medical Engineering">
                                                Department of Biotechnology and Medical Engineering</option>
                                            <option value="Department of Botany">Department of Botany</option>
                                            <option value="Department of Botany and Microbiology">Department of Botany
                                                and Microbiology</option>
                                            <option value="Department of Ceramic Technology">Department of Ceramic
                                                Technology</option>
                                            <option value="Department of Chemical Engineering">Department of Chemical
                                                Engineering</option>
                                            <option value="Department of Chemical Engineering and Physical Sciences">
                                                Department of Chemical Engineering and Physical Sciences</option>
                                            <option value="Department of Chemical Sciences">Department of Chemical
                                                Sciences</option>
                                            <option value="Department of Chemistry">Department of Chemistry</option>
                                            <option value="Department of Chemistry BITS Pilani Rajasthan">Department of
                                                Chemistry BITS Pilani Rajasthan</option>
                                            <option
                                                value="Department of Chemistry G.J.University of Science & Tech. Hisar Haryana">
                                                Department of Chemistry G.J.University of Science & Tech. Hisar Haryana
                                            </option>
                                            <option value="Department of Chemistry Gujarat University Ahemdabad">
                                                Department of Chemistry Gujarat University Ahemdabad</option>
                                            <option
                                                value="Department of Chemistry Guru Jambheshwar University of Science & Technology Hisar Haryana">
                                                Department of Chemistry Guru Jambheshwar University of Science &
                                                Technology Hisar Haryana</option>
                                            <option value="Department of Chemistry IIT Ropar Punjab">Department of
                                                Chemistry IIT Ropar Punjab</option>
                                            <option value="Department of Chemistry IRC Nanomaterial Laboratory">
                                                Department of Chemistry IRC Nanomaterial Laboratory</option>
                                            <option value="Department of Chemistry Meerut College UP">Department of
                                                Chemistry Meerut College UP</option>
                                            <option value="Department of Chemistry School of Sciences">Department of
                                                Chemistry School of Sciences</option>
                                            <option value="Department of Chemistry TIFR Hyderabad Telangana">Department
                                                of Chemistry TIFR Hyderabad Telangana</option>
                                            <option value="Department of Chemistry University of Kalyani West Bengal">
                                                Department of Chemistry University of Kalyani West Bengal</option>
                                            <option value="Department of Chemistry VIT Vellore Tamil Nadu">Department of
                                                Chemistry VIT Vellore Tamil Nadu</option>
                                            <option value="Department of Clothing & Textiles College of  Home Science">
                                                Department of Clothing & Textiles College of Home Science</option>
                                            <option value="Department of Conservative Dentistry and Endodontics">
                                                Department of Conservative Dentistry and Endodontics</option>
                                            <option value="Department of Design">Department of Design</option>
                                            <option value="Department of Earth & Environmental Science">Department of
                                                Earth & Environmental Science</option>
                                            <option value="Department of Earth Science IISER Kolkata">Department of
                                                Earth Science IISER Kolkata</option>
                                            <option value="Department of Earth Sciences">Department of Earth Sciences
                                            </option>
                                            <option value="Department of ECE">Department of ECE</option>
                                            <option value="Department of Electronics and  Communication Engineering">
                                                Department of Electronics and Communication Engineering</option>
                                            <option value="Department of Electronics Systems Engineering">Department of
                                                Electronics Systems Engineering</option>
                                            <option value="Department of Energy">Department of Energy</option>
                                            <option value="Department of Energy Science">Department of Energy Science
                                            </option>
                                            <option value="Department of Entomology">Department of Entomology</option>
                                            <option value="Department of Environment Science">Department of Environment
                                                Science</option>
                                            <option value="Department of Environmental Science">Department of
                                                Environmental Science</option>
                                            <option value="Department of Environmental Science and Engineering">
                                                Department of Environmental Science and Engineering</option>
                                            <option value="Department of Environmental Sciences">Department of
                                                Environmental Sciences</option>
                                            <option value="Department of Environmental Studies">Department of
                                                Environmental Studies</option>
                                            <option value="Department of Food Science and Technology">Department of Food
                                                Science and Technology</option>
                                            <option value="Department of Geology">Department of Geology</option>
                                            <option value="Department of Humanities & Science">Department of Humanities
                                                & Science</option>
                                            <option value="Department of Industrial Chemistry">Department of Industrial
                                                Chemistry</option>
                                            <option value="Department of Integrative Biology">Department of Integrative
                                                Biology</option>
                                            <option value="Department of International Studies">Department of
                                                International Studies</option>
                                            <option value="Department of Life Science LEnME NIT Rourkela">Department of
                                                Life Science LEnME NIT Rourkela</option>
                                            <option value="Department of Materials Science & Engineering">Department of
                                                Materials Science & Engineering</option>
                                            <option value="Department of Mechanical Engineering">Department of
                                                Mechanical Engineering</option>
                                            <option value="Department of Metallurgical & Materials Engineering">
                                                Department of Metallurgical & Materials Engineering</option>
                                            <option
                                                value="Department of Metallurgical and Materials Engineering IIT Patna Bihar">
                                                Department of Metallurgical and Materials Engineering IIT Patna Bihar
                                            </option>
                                            <option value="Department of Metallurgical Engineering">Department of
                                                Metallurgical Engineering</option>
                                            <option value="Department of Metallurgicals Materials Engineering">
                                                Department of Metallurgicals Materials Engineering</option>
                                            <option value="Department of Microbiology">Department of Microbiology
                                            </option>
                                            <option value="Department of Molecular Biology and Genetic Engineering">
                                                Department of Molecular Biology and Genetic Engineering</option>
                                            <option value="Department of Nanotechnology">Department of Nanotechnology
                                            </option>
                                            <option value="Department of Optoelectronics">Department of Optoelectronics
                                            </option>
                                            <option value="Department of Paediatric & Preventive Dentistry">Department
                                                of Paediatric & Preventive Dentistry</option>
                                            <option value="Department of Pediatric and Preventive Dentistry">Department
                                                of Pediatric and Preventive Dentistry</option>
                                            <option
                                                value="Department of Pedodontics Kothiwal Dental College and Research Centre Moradabad">
                                                Department of Pedodontics Kothiwal Dental College and Research Centre
                                                Moradabad</option>
                                            <option value="Department of Periodontology">Department of Periodontology
                                            </option>
                                            <option value="Department of Periodontology and Implantology">Department of
                                                Periodontology and Implantology</option>
                                            <option
                                                value="Department of Periodontology and Oral Implantology MDS Final Year">
                                                Department of Periodontology and Oral Implantology MDS Final Year
                                            </option>
                                            <option value="Department of Petroleum Engineering">Department of Petroleum
                                                Engineering</option>
                                            <option value="Department of Pharmaceutical Chemistry">Department of
                                                Pharmaceutical Chemistry</option>
                                            <option value="Department of Pharmaceutical Chemistry University of Mumbai">
                                                Department of Pharmaceutical Chemistry University of Mumbai</option>
                                            <option value="Department of Pharmaceutical Technology">Department of
                                                Pharmaceutical Technology</option>
                                            <option value="Department of Pharmaceutics">Department of Pharmaceutics
                                            </option>
                                            <option value="Department of Physical Chemistry">Department of Physical
                                                Chemistry</option>
                                            <option value="Department of Physics">Department of Physics</option>
                                            <option value="Department of Physics & Materials Science">Department of
                                                Physics & Materials Science</option>
                                            <option value="Department of Physics and Astrophysics">Department of Physics
                                                and Astrophysics</option>
                                            <option value="Department of Physics and Electronics">Department of Physics
                                                and Electronics</option>
                                            <option value="Department of Physics and Nanotechnology">Department of
                                                Physics and Nanotechnology</option>
                                            <option value="Department of Polymer Science & Technology">Department of
                                                Polymer Science & Technology</option>
                                            <option
                                                value="Department of Postgraduate Chemistry  and Pharmaceutical Imagination">
                                                Department of Postgraduate Chemistry and Pharmaceutical Imagination
                                            </option>
                                            <option value="Department of Production & Industrial Engineering">Department
                                                of Production & Industrial Engineering</option>
                                            <option value="Department of Rasa Shastra & Bhaishajya Kalpna">Department of
                                                Rasa Shastra & Bhaishajya Kalpna</option>
                                            <option value="Department of RS & BK">Department of RS & BK</option>
                                            <option value="Department of Space">Department of Space</option>
                                            <option value="Department of Space Dehradun">Department of Space Dehradun
                                            </option>
                                            <option value="Department of space IIRS ISRO  Dehradun">Department of space
                                                IIRS ISRO Dehradun</option>
                                            <option value="Department of Studies & Research in Physics">Department of
                                                Studies & Research in Physics</option>
                                            <option value="Department of Studies in Chemistry">Department of Studies in
                                                Chemistry</option>
                                            <option value="Department of Studies in Industrial Chemistry">Department of
                                                Studies in Industrial Chemistry</option>
                                            <option value="Department of Studies in Physics">Department of Studies in
                                                Physics</option>
                                            <option value="Department of Zoology and Environmental Sciences">Department
                                                of Zoology and Environmental Sciences</option>
                                            <option value="Dept. of Cons. and Endo.">Dept. of Cons. and Endo.</option>
                                            <option
                                                value="Dept. of Optoelectronics University of Kerala Thiruvananthapuram">
                                                Dept. of Optoelectronics University of Kerala Thiruvananthapuram
                                            </option>
                                            <option value="Discipline of Metallurgy Engineering and Materials Science">
                                                Discipline of Metallurgy Engineering and Materials Science</option>
                                            <option value="Division of Physical Sciences">Division of Physical Sciences
                                            </option>
                                            <option value="Division of Polymer Science & Engineering CSIN-NSL Pune">
                                                Division of Polymer Science & Engineering CSIN-NSL Pune</option>
                                            <option value="Dr. S.S.B. University Institute of Chemical Engg. & Tech.">
                                                Dr. S.S.B. University Institute of Chemical Engg. & Tech.</option>
                                            <option value="Earth Sciences">Earth Sciences</option>
                                            <option value="Earthquake Engineering">Earthquake Engineering</option>
                                            <option value="ECOF Inudustries Pvt Ltd Malur Kolar">ECOF Inudustries Pvt
                                                Ltd Malur Kolar</option>
                                            <option value="Ecology & Environment Group">Ecology & Environment Group
                                            </option>
                                            <option value="ECSO Global Private Limited Gurugram Haryana">ECSO Global
                                                Private Limited Gurugram Haryana</option>
                                            <option value="Electric Mobility and Tribology Research Group">Electric
                                                Mobility and Tribology Research Group</option>
                                            <option value="Electrical Engineering">Electrical Engineering</option>
                                            <option value="Electronic Science Department">Electronic Science Department
                                            </option>
                                            <option value="Electronics and Communication Engineering">Electronics and
                                                Communication Engineering</option>
                                            <option value="Energy Research and Technology Group">Energy Research and
                                                Technology Group</option>
                                            <option value="Energy Research Centre">Energy Research Centre</option>
                                            <option value="Engineering Department">Engineering Department</option>
                                            <option value="Environment & Sustainability Department">Environment &
                                                Sustainability Department</option>
                                            <option value="Environmental Impact Sustainability Division EISD">
                                                Environmental Impact Sustainability Division EISD</option>
                                            <option value="Environmental Science">Environmental Science</option>
                                            <option value="Faculty of Sciences">Faculty of Sciences</option>
                                            <option value="Fir Research Laboratory CSIR-CBRI Roorkee">Fir Research
                                                Laboratory CSIR-CBRI Roorkee</option>
                                            <option value="Fire Research Laboratory CSIR-CBRI  Roorkee">Fire Research
                                                Laboratory CSIR-CBRI Roorkee</option>
                                            <option value="GB PANT UNIVERSITY OF AGRICULTURE AND TECHNOLOGY">GB PANT
                                                UNIVERSITY OF AGRICULTURE AND TECHNOLOGY</option>
                                            <option value="Geology">Geology</option>
                                            <option value="Geology Department">Geology Department</option>
                                            <option value="Health Safety Environment Department">Health Safety
                                                Environment Department</option>
                                            <option value="Humanities and Social Sciences">Humanities and Social
                                                Sciences</option>
                                            <option value="Hydro and Renewable Energy">Hydro and Renewable Energy
                                            </option>
                                            <option value="Hydrology">Hydrology</option>
                                            <option value="INDIRA GANDHI DELHI TECHNICAL UNIVERSITY FOR WOMEN">INDIRA
                                                GANDHI DELHI TECHNICAL UNIVERSITY FOR WOMEN</option>
                                            <option value="Industrial and Waste Utilization Group CSIR-AMPRI Bhopal">
                                                Industrial and Waste Utilization Group CSIR-AMPRI Bhopal</option>
                                            <option value="Industrial Chemistry">Industrial Chemistry</option>
                                            <option value="industry">industry</option>
                                            <option value="Inorganic Chemistry">Inorganic Chemistry</option>
                                            <option value="insti">insti</option>
                                            <option value="instit">instit</option>
                                            <option value="Institute Computer Centre (ICC)">Institute Computer Centre
                                                (ICC)</option>
                                            <option value="Institute Instrumentation Centre (IIC)">Institute
                                                Instrumentation Centre (IIC)</option>
                                            <option value="Instrumentation">Instrumentation</option>
                                            <option value="INTAS Pharmaceuticals Ltd dehradun">INTAS Pharmaceuticals Ltd
                                                dehradun</option>
                                            <option value="Interdisciplinary Biotechnology Unit">Interdisciplinary
                                                Biotechnology Unit</option>
                                            <option value="International Centre for Materials Science">International
                                                Centre for Materials Science</option>
                                            <option value="IRCNHS">IRCNHS</option>
                                            <option value="Jalvigyan Bhawan">Jalvigyan Bhawan</option>
                                            <option value="Labortory">Labortory</option>
                                            <option
                                                value="Labortory for Advanced Research in Polymeric Materials (LARPM)">
                                                Labortory for Advanced Research in Polymeric Materials (LARPM)</option>
                                            <option value="Leather Process Technology Department">Leather Process
                                                Technology Department</option>
                                            <option value="M Pharmacy in Quality Assurance">M Pharmacy in Quality
                                                Assurance</option>
                                            <option value="MAE Department">MAE Department</option>
                                            <option value="Magnetism Laboratory Department of Physics MSU Udaipur">
                                                Magnetism Laboratory Department of Physics MSU Udaipur</option>
                                            <option value="Makino Auto Industries Pvt Ltd">Makino Auto Industries Pvt
                                                Ltd</option>
                                            <option value="Management Studies">Management Studies</option>
                                            <option value="Material and Mechanical Engineering Department">Material and
                                                Mechanical Engineering Department</option>
                                            <option value="material Engineering">material Engineering</option>
                                            <option value="Material Processing and Microsystem Laboratory">Material
                                                Processing and Microsystem Laboratory</option>
                                            <option value="Material Science and Sensor Applications">Material Science
                                                and Sensor Applications</option>
                                            <option value="Materials Engineering">Materials Engineering</option>
                                            <option value="Materials Science">Materials Science</option>
                                            <option value="Materials Science and Engineering">Materials Science and
                                                Engineering</option>
                                            <option value="Materials Science Division">Materials Science Division
                                            </option>
                                            <option value="Mathematics">Mathematics</option>
                                            <option value="Mechanical and Industrial Engineering">Mechanical and
                                                Industrial Engineering</option>
                                            <option value="Mechanical Engineering">Mechanical Engineering</option>
                                            <option value="Metallurgical and Materials Engineering">Metallurgical and
                                                Materials Engineering</option>
                                            <option value="Microbiology">Microbiology</option>
                                            <option value="Mineral Processing Department">Mineral Processing Department
                                            </option>
                                            <option
                                                value="Nano Energy Division Amrita Center for Nanosciences and Molecular Medicine">
                                                Nano Energy Division Amrita Center for Nanosciences and Molecular
                                                Medicine</option>
                                            <option value="Nanomaterial Application Laboratory Department of Physics">
                                                Nanomaterial Application Laboratory Department of Physics</option>
                                            <option value="NanoScience">NanoScience</option>
                                            <option value="National Centre for Nanoscience and Nanotechnology">National
                                                Centre for Nanoscience and Nanotechnology</option>
                                            <option
                                                value="National Institute of Pharmaceutical Education and Research (NIPER) Ahmedabad">
                                                National Institute of Pharmaceutical Education and Research (NIPER)
                                                Ahmedabad</option>
                                            <option value="National Institute of Science and Technology Odisha">National
                                                Institute of Science and Technology Odisha</option>
                                            <option value="Nenotechnology Department">Nenotechnology Department</option>
                                            <option value="New Chemistry Unit">New Chemistry Unit</option>
                                            <option value="NIT PATNA">NIT PATNA</option>
                                            <option value="Organic Building Materials (OBM) Group">Organic Building
                                                Materials (OBM) Group</option>
                                            <option value="Paper Technology">Paper Technology</option>
                                            <option value="Pavement Evaluation Division">Pavement Evaluation Division
                                            </option>
                                            <option value="Pharmaceutical Chemistry Department">Pharmaceutical Chemistry
                                                Department</option>
                                            <option value="Pharmaceutical Sciences">Pharmaceutical Sciences</option>
                                            <option value="Pharmaceutics">Pharmaceutics</option>
                                            <option value="physical">physical</option>
                                            <option value="Physical Chemistry">Physical Chemistry</option>
                                            <option value="Physics">Physics</option>
                                            <option value="Physics & Materials Science">Physics & Materials Science
                                            </option>
                                            <option value="Physics and Photonics Science">Physics and Photonics Science
                                            </option>
                                            <option value="Physics Department">Physics Department</option>
                                            <option value="Physics Department CBSH">Physics Department CBSH</option>
                                            <option value="Polymer and Process Engineering">Polymer and Process
                                                Engineering</option>
                                            <option value="Polymer Science and Technology">Polymer Science and
                                                Technology</option>
                                            <option value="R & D Hindustan Gum & Chemicals Ltd Bhiwani Haryana">R & D
                                                Hindustan Gum & Chemicals Ltd Bhiwani Haryana</option>
                                            <option
                                                value="Radiations & Isotopic Tracers Laboratory CBSH G.B.P.U.A. & T.">
                                                Radiations & Isotopic Tracers Laboratory CBSH G.B.P.U.A. & T.</option>
                                            <option value="Rasa Shastra & Bhaishajya Kalpana ITRA Jamnagar Gujarat">Rasa
                                                Shastra & Bhaishajya Kalpana ITRA Jamnagar Gujarat</option>
                                            <option value="Redox Pharmachem Pvt Ltd IIE Sidcul Haridwar Uttarakhand">
                                                Redox Pharmachem Pvt Ltd IIE Sidcul Haridwar Uttarakhand</option>
                                            <option
                                                value="RNAIS Division Institute of Nuclear Medicine & Allied Sciences Timarpur Delhi">
                                                RNAIS Division Institute of Nuclear Medicine & Allied Sciences Timarpur
                                                Delhi</option>
                                            <option value="S & H (Chemistry)">S & H (Chemistry)</option>
                                            <option value="SARP : LARPM">SARP : LARPM</option>
                                            <option value="School in Physics & Materials Science">School in Physics &
                                                Materials Science</option>
                                            <option value="School of Advanced Chemical Sciences">School of Advanced
                                                Chemical Sciences</option>
                                            <option value="School of Advanced research in Polymers (SARP)">School of
                                                Advanced research in Polymers (SARP)</option>
                                            <option value="School of Advanced Sciences">School of Advanced Sciences
                                            </option>
                                            <option value="School of Applied and Interdisciplinary Science">School of
                                                Applied and Interdisciplinary Science</option>
                                            <option value="School of Basic & Applied Sciences">School of Basic & Applied
                                                Sciences</option>
                                            <option value="School of Basic Sciences">School of Basic Sciences</option>
                                            <option value="School of Basic Sciences IIT Mandi Himanchal Pradesh">School
                                                of Basic Sciences IIT Mandi Himanchal Pradesh</option>
                                            <option value="School of Chemical Engineering and Physical Sciences">School
                                                of Chemical Engineering and Physical Sciences</option>
                                            <option value="School of Chemical Sciences">School of Chemical Sciences
                                            </option>
                                            <option value="School of Chemistry & BioChemistry (SCBC)">School of
                                                Chemistry & BioChemistry (SCBC)</option>
                                            <option value="School of Chemistry and Biochemistry">School of Chemistry and
                                                Biochemistry</option>
                                            <option value="School of Civil Engineering">School of Civil Engineering
                                            </option>
                                            <option value="School of Energy & Environment">School of Energy &
                                                Environment</option>
                                            <option value="School of Environment and Sustainable Development">School of
                                                Environment and Sustainable Development</option>
                                            <option value="School of Material and Mechanical Engineering">School of
                                                Material and Mechanical Engineering</option>
                                            <option value="School of Material Science & Technology">School of Material
                                                Science & Technology</option>
                                            <option
                                                value="School of Materials Science & Nanotechnology Jadavpur University Kolkata">
                                                School of Materials Science & Nanotechnology Jadavpur University Kolkata
                                            </option>
                                            <option value="School of Materials Science & Technology">School of Materials
                                                Science & Technology</option>
                                            <option value="School of Mechanical Engineering">School of Mechanical
                                                Engineering</option>
                                            <option value="School of Nano Sciences">School of Nano Sciences</option>
                                            <option value="School of Petroleum Technology">School of Petroleum
                                                Technology</option>
                                            <option value="School of Pharmaceutical Sciences">School of Pharmaceutical
                                                Sciences</option>
                                            <option
                                                value="School of Pharmaceutical Sciences and  Technology Sardar Bhagwan Singh University Dehradun">
                                                School of Pharmaceutical Sciences and Technology Sardar Bhagwan Singh
                                                University Dehradun</option>
                                            <option value="School of Pharmacy">School of Pharmacy</option>
                                            <option value="School of Physical and Applied Sciences">School of Physical
                                                and Applied Sciences</option>
                                            <option value="School of Physical Sciences">School of Physical Sciences
                                            </option>
                                            <option value="School of Physics & Materials Science">School of Physics &
                                                Materials Science</option>
                                            <option value="School of Studies in Chemistry">School of Studies in
                                                Chemistry</option>
                                            <option value="Sciences">Sciences</option>
                                            <option value="SCNS JNU New Delhi">SCNS JNU New Delhi</option>
                                            <option value="shivalik bimetal">shivalik bimetal</option>
                                            <option value="Solid State Physics Division BARC Mumbai">Solid State Physics
                                                Division BARC Mumbai</option>
                                            <option value="St. Thomas College Thrissur Kerala">St. Thomas College
                                                Thrissur Kerala</option>
                                            <option
                                                value="Suven Pharmaceuticals Limited IDA Pashamylaram Sangareddy Telangana">
                                                Suven Pharmaceuticals Limited IDA Pashamylaram Sangareddy Telangana
                                            </option>
                                            <option
                                                value="Technology Incubation and Entrepreneurship Development Society">
                                                Technology Incubation and Entrepreneurship Development Society</option>
                                            <option value="Textile Technology">Textile Technology</option>
                                            <option value="UIET Chemistry">UIET Chemistry</option>
                                            <option value="Unichem Industries Tohana Haryana">Unichem Industries Tohana
                                                Haryana</option>
                                            <option
                                                value="University Institute of Engineering & Technology Panjab University Chandigarh">
                                                University Institute of Engineering & Technology Panjab University
                                                Chandigarh</option>
                                            <option value="university of mumbai mumbai">university of mumbai mumbai
                                            </option>
                                            <option value="University of Petroleum and Energy Studies Dehradun">
                                                University of Petroleum and Energy Studies Dehradun</option>
                                            <option
                                                value="Uttaranchal Dental College & Medical Research Institute Dehradun">
                                                Uttaranchal Dental College & Medical Research Institute Dehradun
                                            </option>
                                            <option
                                                value="Veterinary Biochemistry College of Veterinary Science and A H Anjora CGKV Durg">
                                                Veterinary Biochemistry College of Veterinary Science and A H Anjora
                                                CGKV Durg</option>
                                            <option value="Water Resources Development and Management">Water Resources
                                                Development and Management</option>
                                            <option value="Wildlife Institute of India Dehradun">Wildlife Institute of
                                                India Dehradun</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Mobile Number</label>
                                        <input type="number" placeholder="Enter Mobile number" class="form-control"
                                            name="phone" value="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Enrolled Program</label>
                                        <select class="form-control" name="program_id" id="student_program_id">
                                            <option value="B.Tech">B.Tech</option>
                                            <option value="M.Tech">M.Tech</option>
                                            <option value="I.D.D">I.D.D</option>
                                            <option value="M.Sc">M.Sc</option>
                                            <option value="PhD">PhD</option>
                                            <option value="Others">Others</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6 program_other hide">
                                    <div class="form-group">
                                        <label>Please specify program/position name</label>
                                        <input type="text" name="program_name" placeholder="Enter program"
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group" data-provide="datepicker" id="student_register_date">
                                        <label>Date of Registration Enrolled program <span
                                                class="required">*</span></label>
                                        <input type="date" id="registration_date" class="form-control"
                                            name="registration_date" value="" required>
                                    </div>
                                </div>
                                <div class="col-md-6 institute_section">
                                    <div class="form-group">
                                        <label>Institute Name</label>
                                        <input type="text" class="form-control" name='org_name'
                                            placeholder="Enter Institute Name">
                                    </div>
                                </div>
                            </div>
                            <div class="supervisor_Section row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Supervisor Name <span class="required">*</span></label>
                                        <select class="form-control" name="supervisor_name" id="supervisor_name"
                                            required>
                                            <option>--select--</option>
                                            <option value=" Rajan Arora" dept="Applied Science and Engineering"
                                                email="rajan.arora@as.iitr.ac.in" emp_id="400119"> Rajan Arora</option>
                                            <option value="A. Upadhyay" dept="Department of Civil Engineering"
                                                email="a.upadhyay@ce.iitr.ac.in" emp_id="100054">A. Upadhyay</option>
                                            <option value="A.K. Sharma"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="ashwani.sharma@bt.iitr.ac.in" emp_id="100334">A.K. Sharma
                                            </option>
                                            <option value="Aalok Misra" dept="Department of Physics"
                                                email="aalok.misra@ph.iitr.ac.in" emp_id="100390">Aalok Misra</option>
                                            <option value="Abhayanand Singh Maurya" dept="Department of Earth Sciences"
                                                email="asmaurya@es.iitr.ac.in" emp_id="100562">Abhayanand Singh Maurya
                                            </option>
                                            <option value="Abhijit Maiti"
                                                dept="Department of Polymer and Process Engineering"
                                                email="abhijit.maiti@pe.iitr.ac.in" emp_id="400140">Abhijit Maiti
                                            </option>
                                            <option value="Abhishek Tewari"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="abhishek@mt.iitr.ac.in" emp_id="100872">Abhishek Tewari</option>
                                            <option value="Abinash Kumar Swain"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="abinash.swain@me.iitr.ac.in" emp_id="100640">Abinash Kumar Swain
                                            </option>
                                            <option value="Absar Ahmad Kazmi" dept="Department of Civil Engineering"
                                                email="absar.kazmi@ce.iitr.ac.in" emp_id="100406">Absar Ahmad Kazmi
                                            </option>
                                            <option value="Aditya Singh" dept="Department of  Civil Engineering"
                                                email="aditya.singh@ce.iitr.ac.in" emp_id="100875">Aditya Singh</option>
                                            <option value="Ajanta Goswami" dept="Department of Earth Sciences"
                                                email="ajanta.goswami@es.iitr.ac.in" emp_id="100710">Ajanta Goswami
                                            </option>
                                            <option value="Ajay" dept="Department of Physics" email="ajay@ph.iitr.ac.in"
                                                emp_id="100735">Ajay</option>
                                            <option value="Ajay Gairola" dept="Department of Civil Engineering"
                                                email="ajay.gairola@ce.iitr.ac.in" emp_id="100368">Ajay Gairola</option>
                                            <option value="Ajay Wasan" dept="Department of Physics"
                                                email="awasan@ph.iitr.ac.in" emp_id="100499">Ajay Wasan</option>
                                            <option value="Ajay Y. Deo" dept="Department of Physics"
                                                email="ajay.deo@ph.iitr.ac.in" emp_id="100601">Ajay Y. Deo</option>
                                            <option value="Ajit K Chaturvedi"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="ajit.chaturvedi@ece.iitr.ac.in" emp_id="100784">Ajit K Chaturvedi
                                            </option>
                                            <option value="Akanksha Tyagi" dept="Department of Civil Engineering"
                                                email="akanksha.tyagi@ce.iitr.ac.in" emp_id="100851">Akanksha Tyagi
                                            </option>
                                            <option value="Akhilesh Gupta"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="akhilesh.gupta@me.iitr.ac.in" emp_id="100106">Akhilesh Gupta
                                            </option>
                                            <option value="Akshay Dvivedi"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="akshaydvivedi@me.iitr.ac.in" emp_id="100549">Akshay Dvivedi
                                            </option>
                                            <option value="Amalendu Patnaik"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="amalendu.patnaik@ece.iitr.ac.in" emp_id="100478">Amalendu Patnaik
                                            </option>
                                            <option value="Ambalika Sharma" dept="Department of Electrical Engineering"
                                                email="ambalika.sharma@ee.iitr.ac.in" emp_id="100078">Ambalika Sharma
                                            </option>
                                            <option value="Amit Agarwal" dept="Department of Civil Engineering"
                                                email="amit.agarwal@ce.iitr.ac.in" emp_id="100813">Amit Agarwal</option>
                                            <option value="Amit Bhosale" dept="Hydro and Renewable Energy"
                                                email="achbhosale@hre.iitr.ac.in" emp_id="100876">Amit Bhosale</option>
                                            <option value="Amit K Sen" dept="Department of Earth Sciences"
                                                email="amit.sen@es.iitr.ac.in" emp_id="100286">Amit K Sen</option>
                                            <option value="Amit Kumar Dhiman" dept="Department of Chemical Engineering"
                                                email="amit.dhiman@ch.iitr.ac.in" emp_id="100482">Amit Kumar Dhiman
                                            </option>
                                            <option value="Anand Bulusu"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="anand.bulusu@ece.iitr.ac.in" emp_id="100524">Anand Bulusu
                                            </option>
                                            <option value="Anasuya Bandyopadhyay"
                                                dept="Department of Polymer and Process Engineering"
                                                email="anasuya.bandyopadhyay@pe.iitr.ac.in" emp_id="400137">Anasuya
                                                Bandyopadhyay</option>
                                            <option value="Andallib Tariq"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="andallib@me.iitr.ac.in" emp_id="100496">Andallib Tariq</option>
                                            <option value="Anil Kumar" dept="Department of Chemistry"
                                                email="anil.kumar@cy.iitr.ac.in" emp_id="100263">Anil Kumar</option>
                                            <option value="Anil Kumar"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="a.kumar@me.iitr.ac.in" emp_id="100103">Anil Kumar</option>
                                            <option value="Anil Kumar"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="anil.kumar@me.iitr.ac.in" emp_id="100607">Anil Kumar</option>
                                            <option value="Anil Kumar Gourishetty" dept="Department of Physics"
                                                email="anil.gourishetty@ph.iitr.ac.in" emp_id="100557">Anil Kumar
                                                Gourishetty</option>
                                            <option value="Anirban Mitra" dept="Department of Physics"
                                                email="anirban.mitra@ph.iitr.ac.in" emp_id="100515">Anirban Mitra
                                            </option>
                                            <option value="ANISH KARMAKAR"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="anish.karmakar@mt.iitr.ac.in" emp_id="100829">ANISH KARMAKAR
                                            </option>
                                            <option value="Anjan Sil"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="anjan.sil@mt.iitr.ac.in" emp_id="100188">Anjan Sil</option>
                                            <option value="Anjaneya Dixit" dept="Department of  Civil Engineering"
                                                email="anjaneya.dixit@ce.iitr.ac.in" emp_id="100998">Anjaneya Dixit
                                            </option>
                                            <option value="Ankit Agarwal" dept="Department of Hydrology"
                                                email="ankit.agarwal@hy.iitr.ac.in" emp_id="100863">Ankit Agarwal
                                            </option>
                                            <option value="Ankit Bansal"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="ankit.bansal@me.iitr.ac.in" emp_id="100639">Ankit Bansal</option>
                                            <option value="Anshu Anand" dept="Department of Chemical Engineering"
                                                email="anshu.anand@ch.iitr.ac.in" emp_id="100738">Anshu Anand</option>
                                            <option value="Anshul Tyagi"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="anshul.tyagi@ece.iitr.ac.in" emp_id="100471">Anshul Tyagi
                                            </option>
                                            <option value="Anubrata Dey" dept="Department of Electrical Engineering"
                                                email="anubrata.dey@ee.iitr.ac.in" emp_id="100709">Anubrata Dey</option>
                                            <option value="Anumita Mishra" dept="Department of Civil Engineering"
                                                email="anumita.mishra@ce.iitr.ac.in" emp_id="100850">Anumita Mishra
                                            </option>
                                            <option value="Anupam Chakrabarti" dept="Department of Civil Engineering"
                                                email="anupam.chakrabarti@ce.iitr.ac.in" emp_id="100474">Anupam
                                                Chakrabarti</option>
                                            <option value="Aparna Tripathi"
                                                dept="Metallurgical and Materials Engineering"
                                                email="aparna.tripathi@mt.iitr.ac.in" emp_id="101007">Aparna Tripathi
                                            </option>
                                            <option value="Apurbba Sharma"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="aks@me.iitr.ac.in" emp_id="100445">Apurbba Sharma</option>
                                            <option value="Arindam Biswas"
                                                dept="Department of Architecture and Planning"
                                                email="arindam.biswas@ar.iitr.ac.in" emp_id="100649">Arindam Biswas
                                            </option>
                                            <option value="Arka Lahiri"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="arka.lahiri@mt.iitr.ac.in" emp_id="100854">Arka Lahiri</option>
                                            <option value="Arnab Datta"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="arnab.datta@ece.iitr.ac.in" emp_id="100618">Arnab Datta</option>
                                            <option value="Arumugam Paramasivan" dept="Department of Physics"
                                                email="arumugam.paramasivan@ph.iitr.ac.in" emp_id="100521">Arumugam
                                                Paramasivan</option>
                                            <option value="Arun K Saraf" dept="Department of Earth Sciences"
                                                email="arun.saraf@es.iitr.ac.in" emp_id="100291">Arun K Saraf</option>
                                            <option value="Arup Kumar Das"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="arup.das@me.iitr.ac.in" emp_id="100669">Arup Kumar Das</option>
                                            <option value="Arup Samanta" dept="Department of Physics"
                                                email="arup.samanta@ph.iitr.ac.in" emp_id="100778">Arup Samanta</option>
                                            <option value="Ashish Pandey"
                                                dept="Department of Water Resources Development and Management"
                                                email="ashish.pandey@wr.iitr.ac.in" emp_id="100479">Ashish Pandey
                                            </option>
                                            <option value="Ashish Yadav" dept="Department of Chemical Engineering"
                                                email="ashish@ch.iitr.ac.in" emp_id="100916">Ashish Yadav</option>
                                            <option value="Ashok Kumar Singh" dept="Department of Chemistry"
                                                email="ashok.singh@cy.iitr.ac.in" emp_id="">Ashok Kumar Singh</option>
                                            <option value="Ashutosh Chamoli" dept="Department of Earth Sciences"
                                                email="a.chamoli@es.iitr.ac.in" emp_id="100652">Ashutosh Chamoli
                                            </option>
                                            <option value="Ashwini Kumar Sharma"
                                                dept="Department of Chemical Engineering" email="ashwini@ch.iitr.ac.in"
                                                emp_id="100858">Ashwini Kumar Sharma</option>
                                            <option value="Avik Bhattacharya"
                                                dept="Department of Electrical Engineering"
                                                email="avik.bhattacharya@ee.iitr.ac.in" emp_id="100644">Avik
                                                Bhattacharya</option>
                                            <option value="Avinash Parashar"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="avinash.parashar@me.iitr.ac.in" emp_id="100667">Avinash Parashar
                                            </option>
                                            <option value="Avlokita Agrawal"
                                                dept="Department of Architecture and Planning"
                                                email="avlokita@ar.iitr.ac.in" emp_id="100605">Avlokita Agrawal</option>
                                            <option value="B. K. Maheshwari"
                                                dept="Department of Earthquake Enggineering"
                                                email="bk.maheshwari@eq.iitr.ac.in" emp_id="100428">B. K. Maheshwari
                                            </option>
                                            <option value="B. R. Gurjar" dept="Department of Civil Engineering"
                                                email="bhola.gurjar@ce.iitr.ac.in" emp_id="100433">B. R. Gurjar</option>
                                            <option value="B. Venkata Manoj Kumar"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="manoj.kumar@mt.iitr.ac.in" emp_id="100566">B. Venkata Manoj Kumar
                                            </option>
                                            <option value="B.S.S. Daniel"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="sundar.daniel@mt.iitr.ac.in" emp_id="100399">B.S.S. Daniel
                                            </option>
                                            <option value="Barjeev Tyagi" dept="Department of Electrical Engineering"
                                                email="barjeev.tyagi@ee.iitr.ac.in" emp_id="100485">Barjeev Tyagi
                                            </option>
                                            <option value="Basant Yadav"
                                                dept="Department of Water Resources Development and Management"
                                                email="basant.yadav@wr.iitr.ac.in" emp_id="100910">Basant Yadav</option>
                                            <option value="Basheshwer Prasad" dept="Department of Chemical Engineering"
                                                email="basheshwer.prasad@ch.iitr.ac.in" emp_id="100169">Basheshwer
                                                Prasad</option>
                                            <option value="Bhanu Mishra"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="bhanu.mishra@me.iitr.ac.in" emp_id="100114">Bhanu Mishra</option>
                                            <option value="Bhanu Prakash Vellanki"
                                                dept="Department of Civil Engineering"
                                                email="bhanuprakashv@ce.iitr.ac.in" emp_id="100706">Bhanu Prakash
                                                Vellanki</option>
                                            <option value="Bhaskar Jyoti Deka" dept="Department of Hydrology"
                                                email="bhaskar.deka@hy.iitr.ac.in" emp_id="100906">Bhaskar Jyoti Deka
                                            </option>
                                            <option value="Bhavesh Bhalja" dept="Department of Electrical Engineering"
                                                email="bhavesh.bhalja@ee.iitr.ac.in" emp_id="100668">Bhavesh Bhalja
                                            </option>
                                            <option value="Bhupendra K. Gandhi"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="bkgandhi@me.iitr.ac.in" emp_id="100120">Bhupendra K. Gandhi
                                            </option>
                                            <option value="Bhupinder Singh" dept="Department of Civil Engineering"
                                                email="bhupinder.singh@ce.iitr.ac.in" emp_id="100436">Bhupinder Singh
                                            </option>
                                            <option value="Bijan Choudhury"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="bijan.choudhury@bt.iitr.ac.in" emp_id="100434">Bijan Choudhury
                                            </option>
                                            <option value="Bikash Mohanty" dept="Department of chemical engineering"
                                                email="bmohanty@iitr.ac.in" emp_id="3575">Bikash Mohanty</option>
                                            <option value="BINA GUPTA" dept="Department of Chemistry"
                                                email="bina.gupta@cy.iitr.ac.in" emp_id="100265">BINA GUPTA</option>
                                            <option value="Binoy Krishna Patra" dept="Department of Physics"
                                                email="binoy.patra@ph.iitr.ac.in" emp_id="100383">Binoy Krishna Patra
                                            </option>
                                            <option value="Biplab Bhattacharya" dept="Department of Earth Sciences"
                                                email="biplab.bhattacharya@es.iitr.ac.in" emp_id="100620">Biplab
                                                Bhattacharya</option>
                                            <option value="Biplab Sarkar"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="bsarkar@ece.iitr.ac.in" emp_id="100814">Biplab Sarkar</option>
                                            <option value="Bishnu Prasad Das"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="bishnu.das@ece.iitr.ac.in" emp_id="100660">Bishnu Prasad Das
                                            </option>
                                            <option value="Biswarup Das" dept="Department of Electrical Engineering"
                                                email="biswarup.das@ee.iitr.ac.in" emp_id="100084">Biswarup Das</option>
                                            <option value="Brajesh Kumar Kaushik"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="brajesh.kaushik@ece.iitr.ac.in" emp_id="100539">Brajesh Kumar
                                                Kaushik</option>
                                            <option value="Brijesh Kumar"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="brijesh@ece.iitr.ac.in" emp_id="100651">Brijesh Kumar</option>
                                            <option value="Brijesh Kumar Yadav" dept="Department of Hydrology"
                                                email="brijesh.yadav@hy.iitr.ac.in" emp_id="100584">Brijesh Kumar Yadav
                                            </option>
                                            <option value="C N Ramachandran" dept="Department of Chemistry"
                                                email="ramcn@cy.iitr.ac.in" emp_id="100604">C N Ramachandran</option>
                                            <option value="C. Veeramani" dept="Department of Chemical Engineering"
                                                email="c.veeramani@ch.iitr.ac.in" emp_id="100580">C. Veeramani</option>
                                            <option value="C.P. Gupta" dept="Department of Electrical Engineering"
                                                email="cpgupta@ee.iitr.ac.in" emp_id="100446">C.P. Gupta</option>
                                            <option value="C.S.P. Ojha" dept="Department of Civil Engineering"
                                                email="c.ojha@ce.iitr.ac.in" emp_id="100043">C.S.P. Ojha</option>
                                            <option value="Chandrajit Balomajumder"
                                                dept="Department of Chemical Engineering"
                                                email="chandrajit.balomajumder@ch.iitr.ac.in" emp_id="100168">Chandrajit
                                                Balomajumder</option>
                                            <option value="Chhaya Sharma" dept="Department of Paper Technology"
                                                email="chhaya.sharma@pt.iitr.ac.in" emp_id="400017">Chhaya Sharma
                                            </option>
                                            <option value="D. Benny Karunakar"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="benny.karunakar@me.iitr.ac.in" emp_id="100517">D. Benny Karunakar
                                            </option>
                                            <option value="D. S. Arya" dept="Department of Hydrology"
                                                email="dsarya@hy.iitr.ac.in" emp_id="100320">D. S. Arya</option>
                                            <option value="D. Shanker" dept="Department of Earthquake Enggineering"
                                                email="d.shanker@eq.iitr.ac.in" emp_id="100205">D. Shanker</option>
                                            <option value="Darshak Bhatt"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="darshak.bhatt@ece.iitr.ac.in" emp_id="100822">Darshak Bhatt
                                            </option>
                                            <option value="Davinder Kaur" dept="Department of Physics"
                                                email="davinder.kaur@ph.iitr.ac.in" emp_id="100254">Davinder Kaur
                                            </option>
                                            <option value="Debabrata Sircar"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="debabrata.sircar@bt.iitr.ac.in" emp_id="100624">Debabrata Sircar
                                            </option>
                                            <option value="Debashis Ghosh"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="debashis.ghosh@ece.iitr.ac.in" emp_id="100509">Debashis Ghosh
                                            </option>
                                            <option value="Debasis Banerjee" dept="Department of Chemistry"
                                                email="debasis.banerjee@cy.iitr.ac.in" emp_id="100719">Debasis Banerjee
                                            </option>
                                            <option value="Debrupa Lahiri"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="debrupa.lahiri@mt.iitr.ac.in" emp_id="100613">Debrupa Lahiri
                                            </option>
                                            <option value="Deepak C. Srivastava" dept="Department of Earth Sciences"
                                                email="deepak.srivastava@es.iitr.ac.in" emp_id="100285">Deepak C.
                                                Srivastava</option>
                                            <option value="Deepak Khare"
                                                dept="Department of Water Resources Development and Management"
                                                email="deepak.khare@wr.iitr.ac.in" emp_id="100353">Deepak Khare</option>
                                            <option value="Deepak Kumar Ojha" dept="Department of Chemical Engineering"
                                                email="dojha@ch.iitr.ac.in" emp_id="100895">Deepak Kumar Ojha</option>
                                            <option value="Deepak Sharma"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="deepak.sharma@bt.iitr.ac.in" emp_id="100700">Deepak Sharma
                                            </option>
                                            <option value="Devendra Puri"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="devendra.puri@mt.iitr.ac.in" emp_id="100187">Devendra Puri
                                            </option>
                                            <option value="Dhanashri M. Joglekar"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="dhanashri.joglekar@me.iitr.ac.in" emp_id="100799">Dhanashri M.
                                                Joglekar</option>
                                            <option value="Dharm Dutt" dept="Department of Paper Technology"
                                                email="dharm.dutt@pt.iitr.ac.in" emp_id="400013">Dharm Dutt</option>
                                            <option value="Dharmendra Singh"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="dharmfec@iitr.ac.in" emp_id="100381">Dharmendra Singh</option>
                                            <option value="Dheeraj K Khatod" dept="Department of Electrical Engineering"
                                                email="dheeraj.khatod@ee.iitr.ac.in" emp_id="100506">Dheeraj K Khatod
                                            </option>
                                            <option value="Dheeraj Kumar"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="dheeraj.kumar@ece.iitr.ac.in" emp_id="100834">Dheeraj Kumar
                                            </option>
                                            <option value="Dheeraj Kumar" dept="Department of Chemistry"
                                                email="dheeraj.kumar@cy.iitr.ac.in" emp_id="100812">Dheeraj Kumar
                                            </option>
                                            <option value="Dheerendra K. Dwivedi"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="dwivedi@me.iitr.ac.in" emp_id="100405">Dheerendra K. Dwivedi
                                            </option>
                                            <option value="Dhish Kumar Saxena"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="dhish.saxena@me.iitr.ac.in" emp_id="100603">Dhish Kumar Saxena
                                            </option>
                                            <option value="Dibakar Roychowdhury" dept="Department of Physics"
                                                email="dibakar.roychowdhury@ph.iitr.ac.in" emp_id="100817">Dibakar
                                                Roychowdhury</option>
                                            <option value="Dinesh Kumar"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="dinesh.kumar@me.iitr.ac.in" emp_id="100117">Dinesh Kumar</option>
                                            <option value="Dr Anuj Sharma" dept="Department of Chemistry"
                                                email="anuj.sharma@cy.iitr.ac.in" emp_id="100573">Dr Anuj Sharma
                                            </option>
                                            <option value="Dr. Amit Choudhary"
                                                dept="Mechanical and Industrial Engineering"
                                                email="amit.choudhary@me.iitr.ac.in" emp_id="100943">Dr. Amit Choudhary
                                            </option>
                                            <option value="Dr. Pinki Sharma" dept="Department of Hydrology"
                                                email="pinki.hy@sric.iitr.ac.in" emp_id="1374">Dr. Pinki Sharma</option>
                                            <option value="Dr. Prakash Biswas" dept="Department of Chemical Engineering"
                                                email="prakash.biswas@ch.iitr.ac.in" emp_id="100540">Dr. Prakash Biswas
                                            </option>
                                            <option value="Dr. Vipin Chawla"
                                                dept="Institute Instrumentation Centre (IIC)"
                                                email="vipin.phy@gmail.com" emp_id="1008351">Dr. Vipin Chawla</option>
                                            <option value="E. Rajasekar" dept="Department of Architecture and Planning"
                                                email="raj@ar.iitr.ac.in" emp_id="100712">E. Rajasekar</option>
                                            <option value="Eugene Fernandez" dept="Department of Electrical Engineering"
                                                email="eugene.fernandez@ee.iitr.ac.in" emp_id="100076">Eugene Fernandez
                                            </option>
                                            <option value="G. P. Chaudhari"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="g.chaudhari@mt.iitr.ac.in" emp_id="100463">G. P. Chaudhari
                                            </option>
                                            <option value="G.D. Ransinchung R.N." dept="Department of Civil Engineering"
                                                email="g.n@ce.iitr.ac.in" emp_id="100551">G.D. Ransinchung R.N.</option>
                                            <option value="G.D. Varma" dept="Department of Physics"
                                                email="g.varma@ph.iitr.ac.in" emp_id="100253">G.D. Varma</option>
                                            <option value="G.N. Pillai" dept="Department of Electrical Engineering"
                                                email="gn.pillai@ee.iitr.ac.in" emp_id="100394">G.N. Pillai</option>
                                            <option value="Ganesh Kumbhar" dept="Department of Electrical Engineering"
                                                email="ganesh.kumbhar@ee.iitr.ac.in" emp_id="100577">Ganesh Kumbhar
                                            </option>
                                            <option value="Gargi Singh" dept="Department of Civil Engineering"
                                                email="gargi.singh@ce.iitr.ac.in" emp_id="100762">Gargi Singh</option>
                                            <option value="Gaurav Manik"
                                                dept="Department of Polymer and Process Engineering"
                                                email="gaurav.manik@pe.iitr.ac.in" emp_id="400136">Gaurav Manik</option>
                                            <option value="Gaurav Raheja" dept="Department of Architecture and Planning"
                                                email="gaurav.raheja@ar.iitr.ac.in" emp_id="100444">Gaurav Raheja
                                            </option>
                                            <option value="Gaurav Sharma" dept="Department of Chemical Engineering"
                                                email="gaurav.sharma@ch.iitr.ac.in" emp_id="100572">Gaurav Sharma
                                            </option>
                                            <option value="Gautam Agarwal"
                                                dept="Department of Metallurgical & Materials Engineering"
                                                email="gautam.agarwal@mt.iitr.ac.in" emp_id="100932">Gautam Agarwal
                                            </option>
                                            <option value="Girish K Singh" dept="Department of Electrical Engineering"
                                                email="girish.singh@ee.iitr.ac.in" emp_id="100080">Girish K Singh
                                            </option>
                                            <option value="Gnanamani Elumalai" dept="Department of Chemistry"
                                                email="gnanam@cy.iitr.ac.in" emp_id="100884">Gnanamani Elumalai</option>
                                            <option value="Govind J Chakrapani" dept="Department of Earth Sciences"
                                                email="govind.chakrapani@es.iitr.ac.in" emp_id="100303">Govind J
                                                Chakrapani</option>
                                            <option value="Hari Prakash Veluswamy"
                                                dept="Department of Chemical Engineering"
                                                email="hariprakashv@ch.iitr.ac.in" emp_id="100861">Hari Prakash
                                                Veluswamy</option>
                                            <option value="Harsh Chauhan"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="harsh.chauhan@bt.iitr.ac.in" emp_id="100677">Harsh Chauhan
                                            </option>
                                            <option value="Harshit Mittal" dept="Institute Instrumentation Centre (IIC)"
                                                email="harshitmittal260@gmail.com" emp_id="654321">Harshit Mittal
                                            </option>
                                            <option value="Head IIC" dept="Institute Instrumentation Centre (IIC)"
                                                email="iic@iitr.ac.in" emp_id="198745">Head IIC</option>
                                            <option value="Hem C. Kandpal" dept="Department of Chemistry"
                                                email="hem.kandpal@cy.iitr.ac.in" emp_id="100596">Hem C. Kandpal
                                            </option>
                                            <option value="Himanshu Joshi" dept="Department of Hydrology"
                                                email="himanshu.joshi@hy.iitr.ac.in" emp_id="100316">Himanshu Joshi
                                            </option>
                                            <option value="Hugo Germain"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="hugo.germain@bt.iitr.ac.in" emp_id="">Hugo Germain</option>
                                            <option value="Idhaya Chandhiran"
                                                dept="Department of Water Resources Development and Management"
                                                email="idhaya@wr.iitr.ac.in" emp_id="100877">Idhaya Chandhiran</option>
                                            <option value="Ila Gupta" dept="Department of Architecture and Planning"
                                                email="ila.gupta@ar.iitr.ac.in" emp_id="100155">Ila Gupta</option>
                                            <option value="Inderdeep Singh"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="inderdeep.singh@me.iitr.ac.in" emp_id="100442">Inderdeep Singh
                                            </option>
                                            <option value="Indra Gupta" dept="Department of Electrical Engineering"
                                                email="indra.gupta@ee.iitr.ac.in" emp_id="100075">Indra Gupta</option>
                                            <option value="Indra Vir Singh"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="ivsingh@me.iitr.ac.in" emp_id="100483">Indra Vir Singh</option>
                                            <option value="Indrajit Ghosh" dept="Department of Civil Engineering"
                                                email="indrajit.ghosh@ce.iitr.ac.in" emp_id="100583">Indrajit Ghosh
                                            </option>
                                            <option value="Indranil Lahiri"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="indranil.lahiri@mt.iitr.ac.in" emp_id="100612">Indranil Lahiri
                                            </option>
                                            <option value="J. P. Narayan" dept="Department of Earthquake Enggineering"
                                                email="jp.narayan@eq.iitr.ac.in" emp_id="100206">J. P. Narayan</option>
                                            <option value="Jagdish Prasad Sahoo" dept="Department of Civil Engineering"
                                                email="jagdish.sahoo@ce.iitr.ac.in" emp_id="100645">Jagdish Prasad Sahoo
                                            </option>
                                            <option value="Jayanta Kumar Ghosh" dept="Department of Civil Engineering"
                                                email="jayanta.ghosh@ce.iitr.ac.in" emp_id="100049">Jayanta Kumar Ghosh
                                            </option>
                                            <option value="Jaydev Dabbas" dept="Applied Science and Engineering"
                                                email="jaydev@as.iitr.ac.in" emp_id="400129">Jaydev Dabbas</option>
                                            <option value="Jeevanand Seshadrinath"
                                                dept="Department of Electrical Engineering"
                                                email="jeevanand.seshadrinath@ee.iitr.ac.in" emp_id="100782">Jeevanand
                                                Seshadrinath</option>
                                            <option value="Joshi Anand" dept="Department of Earth Sciences"
                                                email="joshi.anand@es.iitr.ac.in" emp_id="100481">Joshi Anand</option>
                                            <option value="Josodhir Das" dept="Department of Earthquake Enggineering"
                                                email="josodhir.das@eq.iitr.ac.in" emp_id="100419">Josodhir Das</option>
                                            <option value="K. R. Justin Thomas" dept="Department of Chemistry"
                                                email="krjt@cy.iitr.ac.in" emp_id="100451">K. R. Justin Thomas</option>
                                            <option value="K. S. Kasiviswanathan"
                                                dept="Department of Water Resources Development and Management"
                                                email="k.kasiviswanathan@wr.iitr.ac.in" emp_id="100841">K. S.
                                                Kasiviswanathan</option>
                                            <option value="K.C. Gupta" dept="Department of Chemistry"
                                                email="k.gupta@cy.iitr.ac.in" emp_id="100267">K.C. Gupta</option>
                                            <option value="K.S. Prasad Hari" dept="Department of Civil Engineering"
                                                email="k.hari@ce.iitr.ac.in" emp_id="100050">K.S. Prasad Hari</option>
                                            <option value="K.S. Suresh"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="ks.suresh@mt.iitr.ac.in" emp_id="100750">K.S. Suresh</option>
                                            <option value="Kalyan Sadhu" dept="Department of Chemistry"
                                                email="sadhu@cy.iitr.ac.in" emp_id="100684">Kalyan Sadhu</option>
                                            <option value="Kamal" dept="Department of Earth Sciences"
                                                email="kamal.@es.iitr.ac.in" emp_id="100454">Kamal</option>
                                            <option value="Kamal Jain" dept="Department of Civil Engineering"
                                                email="kamal.jain@ce.iitr.ac.in" emp_id="100039">Kamal Jain</option>
                                            <option value="Kanhaiya Lal Yadav" dept="Department of Physics"
                                                email="kanhaiya.yadav@ph.iitr.ac.in" emp_id="100255">Kanhaiya Lal Yadav
                                            </option>
                                            <option value="Karun Rawat"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="karun.rawat@ece.iitr.ac.in" emp_id="100704">Karun Rawat</option>
                                            <option value="Kaushik Ghosh" dept="Department of Chemistry"
                                                email="kaushik.ghosh@cy.iitr.ac.in" emp_id="100449">Kaushik Ghosh
                                            </option>
                                            <option value="Kaushik Pal"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="kaushik@me.iitr.ac.in" emp_id="100592">Kaushik Pal</option>
                                            <option value="Kaushik Parida" dept="Polymer and Process Engineering"
                                                email="kaushik.parida@pe.iitr.ac.in" emp_id="400159">Kaushik Parida
                                            </option>
                                            <option value="Kaustav Chatterjee" dept="Department of Civil Engineering"
                                                email="kaustav.chatterjee@ce.iitr.ac.in" emp_id="100766">Kaustav
                                                Chatterjee</option>
                                            <option value="KC GUPTA" dept="Department of Chemistry"
                                                email="kcgupta@cy.iitr.ac.in" emp_id="100267">KC GUPTA</option>
                                            <option value="Kiran Ambatipudi"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="kiran.ambatipudi@bt.iitr.ac.in" emp_id="100642">Kiran Ambatipudi
                                            </option>
                                            <option value="Kirti Bhushan Mishra"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="kirti.mishra@me.iitr.ac.in" emp_id="100729">Kirti Bhushan Mishra
                                            </option>
                                            <option value="Kirtiraj K. Gaikwad" dept="Department of Paper Technology"
                                                email="kirtiraj.gaikwad@pt.iitr.ac.in" emp_id="400154">Kirtiraj K.
                                                Gaikwad</option>
                                            <option value="Krishna M. Singh"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="krishna.singh@me.iitr.ac.in" emp_id="100378">Krishna M. Singh
                                            </option>
                                            <option value="Krishna Mohan Poluri"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="krishna.poluri@bt.iitr.ac.in" emp_id="100637">Krishna Mohan
                                                Poluri</option>
                                            <option value="Krishnan Murugesan"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="krishnan.murugesan@me.iitr.ac.in" emp_id="100437">Krishnan
                                                Murugesan</option>
                                            <option value="Lakra Harshit Sosan"
                                                dept="Department of Architecture and planning"
                                                email="harshit.lakra@ar.iitr.ac.in" emp_id="100606">Lakra Harshit Sosan
                                            </option>
                                            <option value="Lalita Sharma" dept="Department of Physics"
                                                email="lalita.sharma@ph.iitr.ac.in" emp_id="100565">Lalita Sharma
                                            </option>
                                            <option value="M. Felix Orlando" dept="Department of Electrical Engineering"
                                                email="m.orlando@ee.iitr.ac.in" emp_id="100746">M. Felix Orlando
                                            </option>
                                            <option value="M. L. Sharma" dept="Department of Earthquake Enggineering"
                                                email="m.sharma@eq.iitr.ac.in" emp_id="100201">M. L. Sharma</option>
                                            <option value="M. Parida" dept="Department of Civil Engineering"
                                                email="m.parida@ce.iitr.ac.in" emp_id="100066">M. Parida</option>
                                            <option value="M. Perumal" dept="Department of Hydrology"
                                                email="m.perumal@hy.iitr.ac.in" emp_id="100321">M. Perumal</option>
                                            <option value="M. Sankar" dept="Department of Chemistry"
                                                email="m.sankar@cy.iitr.ac.in" emp_id="100576">M. Sankar</option>
                                            <option value="M.K. Pathak" dept="Department of Electrical Engineering"
                                                email="mukesh.pathak@ee.iitr.ac.in" emp_id="100495">M.K. Pathak</option>
                                            <option value="M.K. Singhal" dept="Department of Hydro and Renewable Energy"
                                                email="m.singhal@hre.iitr.ac.in" emp_id="100366">M.K. Singhal</option>
                                            <option value="M.R. Maurya" dept="Department of Chemistry"
                                                email="m.maurya@cy.iitr.ac.in" emp_id="100269">M.R. Maurya</option>
                                            <option value="M.V. Sunil Krishna" dept="Department of Physics"
                                                email="mv.sunilkrishna@ph.iitr.ac.in" emp_id="100559">M.V. Sunil Krishna
                                            </option>
                                            <option value="Mahendra Singh" dept="Department of Civil Engineering"
                                                email="mahendra.singh@ce.iitr.ac.in" emp_id="100052">Mahendra Singh
                                            </option>
                                            <option value="Mahua Mukherjee"
                                                dept="Department of Architecture and Planning"
                                                email="mahua.mukherjee@ar.iitr.ac.in" emp_id="100157">Mahua Mukherjee
                                            </option>
                                            <option value="Mala Nath" dept="Department of Chemistry"
                                                email="mala.nath@cy.iitr.ac.in" emp_id="100261">Mala Nath</option>
                                            <option value="Manavvi Suneja"
                                                dept="Department of Architecture and Planning"
                                                email="manavvi.suneja@ar.iitr.ac.in" emp_id="100751">Manavvi Suneja
                                            </option>
                                            <option value="Manish Kumar Singh" dept="Humanities and Social Sciences"
                                                email="mks@hs.iitr.ac.in" emp_id="100941">Manish Kumar Singh</option>
                                            <option value="Manish M. Joglekar"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="manish.joglekar@me.iitr.ac.in" emp_id="100615">Manish M. Joglekar
                                            </option>
                                            <option value="Manish Mishra"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="mmishra@me.iitr.ac.in" emp_id="100514">Manish Mishra</option>
                                            <option value="Manish Shrikhande"
                                                dept="Department of Earthquake Enggineering"
                                                email="manish.shrikhande@eq.iitr.ac.in" emp_id="100209">Manish
                                                Shrikhande</option>
                                            <option value="Manoj Jain" dept="Hydrology" email="manoj.jain@hy.iitr.ac.in"
                                                emp_id="100473">Manoj Jain</option>
                                            <option value="Manoj Tripathy" dept="Department of Electrical Engineering"
                                                email="manoj.tripathy@ee.iitr.ac.in" emp_id="100571">Manoj Tripathy
                                            </option>
                                            <option value="Maya S Nair"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="maya.nair@bt.iitr.ac.in" emp_id="100536">Maya S Nair</option>
                                            <option value="Mayank Goswami" dept="Department of Physics"
                                                email="mayank.goswami@ph.iitr.ac.in" emp_id="100776">Mayank Goswami
                                            </option>
                                            <option value="Meenakshi Rawat"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="meenakshi.rawat@ece.iitr.ac.in" emp_id="100676">Meenakshi Rawat
                                            </option>
                                            <option value="Milli Pant" dept="Applied Science and Engineering"
                                                email="pant.milli@as.iitr.ac.in" emp_id="400117">Milli Pant</option>
                                            <option value="Mishra Akhilesh Kumar" dept="Department of Physics"
                                                email="akhilesh.mishra@ph.iitr.ac.in" emp_id="100808">Mishra Akhilesh
                                                Kumar</option>
                                            <option value="Mohammad Israil" dept="Department of Earth Sciences"
                                                email="mohammad.israil@es.iitr.ac.in" emp_id="100302">Mohammad Israil
                                            </option>
                                            <option value="Mohd. Ashraf Iqbal" dept="Department of Civil Engineering"
                                                email="ashraf.iqbal@ce.iitr.ac.in" emp_id="100477">Mohd. Ashraf Iqbal
                                            </option>
                                            <option value="Monojit Bag" dept="Department of Physics"
                                                email="monojit.bag@ph.iitr.ac.in" emp_id="100753">Monojit Bag</option>
                                            <option value="Moumita Maiti" dept="Department of Physics"
                                                email="moumita.maiti@ph.iitr.ac.in" emp_id="100611">Moumita Maiti
                                            </option>
                                            <option value="Mukesh Bhardwaj"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="mukesh.bhardwaj@mt.iitr.ac.in" emp_id="100537">Mukesh Bhardwaj
                                            </option>
                                            <option value="MV Kartikeyan"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="kartik@ece.iitr.ac.in" emp_id="100370">MV Kartikeyan</option>
                                            <option value="N. Siva Mohan Reddy"
                                                dept="Department of Chemical Engineering" email="n.reddy@ch.iitr.ac.in"
                                                emp_id="100707">N. Siva Mohan Reddy</option>
                                            <option value="N.K. Goel" dept="Department of Hydrology"
                                                email="nkgoel@hy.iitr.ac.in" emp_id="100317">N.K. Goel</option>
                                            <option value="N.P. Padhy" dept="Department of Electrical Engineering"
                                                email="n.padhy@ee.iitr.ac.in" emp_id="100083">N.P. Padhy</option>
                                            <option value="Nachiketa Rai" dept="Department of Earth Sciences"
                                                email="n.rai@es.iitr.ac.in" emp_id="100779">Nachiketa Rai</option>
                                            <option value="Nagendra P. Pathak"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="nagendra.pathak@ece.iitr.ac.in" emp_id="100470">Nagendra P.
                                                Pathak</option>
                                            <option value="Narayan Chandra Mishra"
                                                dept="Department of Polymer and Process Engineering"
                                                email="narayan.mishra@pe.iitr.ac.in" emp_id="400118">Narayan Chandra
                                                Mishra</option>
                                            <option value="Naseem Ahmed" dept="Department of Chemistry"
                                                email="naseem.ahmed@cy.iitr.ac.in" emp_id="100505">Naseem Ahmed</option>
                                            <option value="Nataraj S. Huliyar" dept="Department of Physics"
                                                email="hsnataraj@ph.iitr.ac.in" emp_id="100617">Nataraj S. Huliyar
                                            </option>
                                            <option value="Naveen Kumar Navani"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="naveen.navani@bt.iitr.ac.in" emp_id="100504">Naveen Kumar Navani
                                            </option>
                                            <option value="Navneet Arora"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="navneet.arora@me.iitr.ac.in" emp_id="100118">Navneet Arora
                                            </option>
                                            <option value="Nikhil Dhawan"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="nikhil.dhawan@mt.iitr.ac.in" emp_id="100714">Nikhil Dhawan
                                            </option>
                                            <option value="Nikhil Saboo" dept="Department of  Civil Engineering"
                                                email="nikhil.saboo@ce.iitr.ac.in" emp_id="100945">Nikhil Saboo</option>
                                            <option value="Nitin Khandelwal" dept="Hydrology"
                                                email="nitin.khandelwal@hy.iitr.ac.in" emp_id="101017">Nitin Khandelwal
                                            </option>
                                            <option value="Niwesh Ojha" dept="Department of Chemical Engineering"
                                                email="niwesh.ch@sric.iitr.ac.in" emp_id="1238976">Niwesh Ojha</option>
                                            <option value="P. Bhargava" dept="Department of Civil Engineering"
                                                email="p.bhargava@ce.iitr.ac.in" emp_id="100040">P. Bhargava</option>
                                            <option value="P. C. Ashwin Kumar"
                                                dept="Department of Earthquake Enggineering"
                                                email="ashwin.pc@eq.iitr.ac.in" emp_id="100791">P. C. Ashwin Kumar
                                            </option>
                                            <option value="P. Gopinath"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="gopi@bt.iitr.ac.in" emp_id="100575">P. Gopinath</option>
                                            <option value="P. Jeevanandam" dept="Department of Chemistry"
                                                email="p.jeevanandam@cy.iitr.ac.in" emp_id="100464">P. Jeevanandam
                                            </option>
                                            <option value="P. S. Chani" dept="Department of Architecture and Planning"
                                                email="p.chani@ar.iitr.ac.in" emp_id="100156">P. S. Chani</option>
                                            <option value="P. Sanyal" dept="Department of Physics"
                                                email="p.sanyal@ph.iitr.ac.in" emp_id="100625">P. Sanyal</option>
                                            <option value="P. Sumathi" dept="Department of Electrical Engineering"
                                                email="p.sumathi@ee.iitr.ac.in" emp_id="100574">P. Sumathi</option>
                                            <option value="P.K. Garg" dept="Department of Civil Engineering"
                                                email="p.garg@ce.iitr.ac.in" emp_id="100037">P.K. Garg</option>
                                            <option value="Pallavi Chattopadhyay" dept="Earth Sciences"
                                                email="cpallavi@es.iitr.ac.in" emp_id="100711">Pallavi Chattopadhyay
                                            </option>
                                            <option value="Pallavi Debnath" dept="Department of Chemistry"
                                                email="pallavi.debnath@cy.iitr.ac.in" emp_id="100567">Pallavi Debnath
                                            </option>
                                            <option value="Pankaj Agrawal" dept="Department of Earthquake Enggineering"
                                                email="pankaj.agrawal@eq.iitr.ac.in" emp_id="100208">Pankaj Agrawal
                                            </option>
                                            <option value="Paritosh Mohanty" dept="Department of Chemistry"
                                                email="pm@cy.iitr.ac.in" emp_id="100734">Paritosh Mohanty</option>
                                            <option value="Partha Roy"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="partha.roy@bt.iitr.ac.in" emp_id="100388">Partha Roy</option>
                                            <option value="Patit Paban Kundu" dept="Department of Chemical Engineering"
                                                email="patit.kundu@ch.iitr.ac.in" emp_id="100761">Patit Paban Kundu
                                            </option>
                                            <option value="Pavan Kumar B.V.V.S" dept="Department of Chemistry"
                                                email="pavan.bosukonda@cy.iitr.ac.in" emp_id="100867">Pavan Kumar
                                                B.V.V.S</option>
                                            <option value="Pawan K Agrawal"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="pawan.agrawal@bt.iitr.ac.in" emp_id="">Pawan K Agrawal</option>
                                            <option value="Pitambar Pati" dept="Department of Earth Sciences"
                                                email="pitambar.pati@es.iitr.ac.in" emp_id="100619">Pitambar Pati
                                            </option>
                                            <option value="Poonam Choudhary"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="poonamchoudhary@bt.iitr.ac.in" emp_id="101006">Poonam Choudhary
                                            </option>
                                            <option value="Prabhat Kumar Mandal"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="prabhat.mandal@bt.iitr.ac.in" emp_id="100638">Prabhat Kumar
                                                Mandal</option>
                                            <option value="Pradeep K. Jha"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="pradeep.jha@me.iitr.ac.in" emp_id="100480">Pradeep K. Jha
                                            </option>
                                            <option value="Pradeep K. Sahoo (On Long Leave)"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="pradeep.sahoo@me.iitr.ac.in" emp_id="100119">Pradeep K. Sahoo (On
                                                Long Leave)</option>
                                            <option value="Pradeep Kumar"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="pradeep.kumar@me.iitr.ac.in" emp_id="100113">Pradeep Kumar
                                            </option>
                                            <option value="Pradeep Srivastava" dept="Earth Sciences"
                                                email="pradeep@es.iitr.ac.in" emp_id="100947">Pradeep Srivastava
                                            </option>
                                            <option value="Pradhan Sarada Prasad" dept="Department of Earth Sciences"
                                                email="sppradhan@es.iitr.ac.in" emp_id="100723">Pradhan Sarada Prasad
                                            </option>
                                            <option value="Pradip K. Maji"
                                                dept="Department of Polymer and Process Engineering"
                                                email="pradip@pe.iitr.ac.in" emp_id="400141">Pradip K. Maji</option>
                                            <option value="Pramod Agarwal" dept="Department of Electrical Engineering"
                                                email="pramod.agarwal@ee.iitr.ac.in" emp_id="100074">Pramod Agarwal
                                            </option>
                                            <option value="Pramod Kumar" dept="Department of Civil Engineering"
                                                email="pramod.kumar@ce.iitr.ac.in" emp_id="100055">Pramod Kumar</option>
                                            <option value="Pramod Kumar Gupta" dept="Department of Civil Engineering"
                                                email="pramod.gupta@ce.iitr.ac.in" emp_id="100461">Pramod Kumar Gupta
                                            </option>
                                            <option value="Pramod Kumar Jain (On Long Leave)"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="pramod.jain@me.iitr.ac.in" emp_id="100115">Pramod Kumar Jain (On
                                                Long Leave)</option>
                                            <option value="Pramod Kumar Sharma" dept="Civil Engineering"
                                                email="pramod.sharma@ce.iitr.ac.in" emp_id="100508">Pramod Kumar Sharma
                                            </option>
                                            <option value="Pranita P. Sarangi"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="pranita.sarangi@bt.iitr.ac.in" emp_id="100643">Pranita P. Sarangi
                                            </option>
                                            <option value="Prasenjit Kar" dept="Department of Chemistry"
                                                email="prasenjit.kar@cy.iitr.ac.in" emp_id="100627">Prasenjit Kar
                                            </option>
                                            <option value="Prasenjit Mondal" dept="Department of Chemical Engineering"
                                                email="prasenjit.mondal@ch.iitr.ac.in" emp_id="100530">Prasenjit Mondal
                                            </option>
                                            <option value="Prateek Kumar Jha" dept="Department of Chemical Engineering"
                                                email="prateek.jha@ch.iitr.ac.in" emp_id="100682">Prateek Kumar Jha
                                            </option>
                                            <option value="Pratham Arora"
                                                dept="Department of Hydro and Renewable Energy"
                                                email="pratham.arora@hre.iitr.ac.in" emp_id="100852">Pratham Arora
                                            </option>
                                            <option value="Praveen C Srivastava" dept="Department of Physics"
                                                email="praveen.srivastava@ph.iitr.ac.in" emp_id="100597">Praveen C
                                                Srivastava</option>
                                            <option value="Praveen Kumar" dept="Department of Civil Engineering"
                                                email="praveen.kumar@ce.iitr.ac.in" emp_id="100067">Praveen Kumar
                                            </option>
                                            <option value="Pravindra Kumar"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="pravindra.kumar@bt.iitr.ac.in" emp_id="100441">Pravindra Kumar
                                            </option>
                                            <option value="Premalata Jena" dept="Department of Electrical Engineering"
                                                email="premalata.jena@ee.iitr.ac.in" emp_id="100585">Premalata Jena
                                            </option>
                                            <option value="Prince Tiwari"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="prince.tiwari@bt.iitr.ac.in" emp_id="100999">Prince Tiwari
                                            </option>
                                            <option value="Priti Maheshwari" dept="Department of Civil Engineering"
                                                email="priti.maheshwari@ce.iitr.ac.in" emp_id="100435">Priti Maheshwari
                                            </option>
                                            <option value="Prof Arun Kumar"
                                                dept="Department of Hydro and Renewable Energy"
                                                email="arun.kumar@hre.iitr.ac.in" emp_id="100362">Prof Arun Kumar
                                            </option>
                                            <option value="Prof. K.K. Pant" dept="Department of Chemical Engineering"
                                                email="kkpant@ch.iitr.ac.in" emp_id="101000">Prof. K.K. Pant</option>
                                            <option value="Prof. M.L Kansal"
                                                dept="Department of Water Resources Development and Management"
                                                email="mlk@wr.iitr.ac.in" emp_id="100352">Prof. M.L Kansal</option>
                                            <option value="Puneet Gupta" dept="Department of Chemistry"
                                                email="puneet.gupta@cy.iitr.ac.in" emp_id="100810">Puneet Gupta</option>
                                            <option value="Puneet Jain" dept="Department of Physics"
                                                email="puneet.jain@ph.iitr.ac.in" emp_id="100650">Puneet Jain</option>
                                            <option value="Pushparaj Mani Pathak"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="pushparaj.pathak@me.iitr.ac.in" emp_id="100450">Pushparaj Mani
                                                Pathak</option>
                                            <option value="Pushplata" dept="Department of Architecture and Planning"
                                                email="pushplata.@ar.iitr.ac.in" emp_id="100159">Pushplata</option>
                                            <option value="Pyari Mohan Pradhan"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="pmpradhan@ece.iitr.ac.in" emp_id="100675">Pyari Mohan Pradhan
                                            </option>
                                            <option value="R . N .GOYAL" dept="Department of Chemistry"
                                                email="r.goyal@cy.iitr.ac.in" emp_id="">R . N .GOYAL</option>
                                            <option value="R. Krishnamurthy" dept="Department of Earth Sciences"
                                                email="r.krishnamurthi@es.iitr.ac.in" emp_id="100382">R. Krishnamurthy
                                            </option>
                                            <option value="R. N. Dubey" dept="Department of Earthquake Enggineering"
                                                email="rn.dubey@eq.iitr.ac.in" emp_id="100200">R. N. Dubey</option>
                                            <option value="R. Pad Padmanabhan"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="r.padmanabhan@bt.iitr.ac.in" emp_id="">R. Pad Padmanabhan
                                            </option>
                                            <option value="R. Prasad"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="ramasare.prasad@bt.iitr.ac.in" emp_id="100332">R. Prasad</option>
                                            <option value="R. Vinnarasi" dept="Department of  Civil Engineering"
                                                email="vinnarasi@ce.iitr.ac.in" emp_id="100887">R. Vinnarasi</option>
                                            <option value="R.D. Garg" dept="Department of Civil Engineering"
                                                email="rdgarg@ce.iitr.ac.in" emp_id="100492">R.D. Garg</option>
                                            <option value="R.K. Dutta" dept="Department of Chemistry"
                                                email="r.dutta@cy.iitr.ac.in" emp_id="100460">R.K. Dutta</option>
                                            <option value="R.P. Saini" dept="Department of Hydro and Renewable Energy"
                                                email="rp.saini@hre.iitr.ac.in" emp_id="100365">R.P. Saini</option>
                                            <option value="R.P. Singh"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="r.singh@bt.iitr.ac.in" emp_id="100331">R.P. Singh</option>
                                            <option value="R.S. Anand" dept="Department of Electrical Engineering"
                                                email="r.anand@ee.iitr.ac.in" emp_id="100082">R.S. Anand</option>
                                            <option value="Rahul S. Mulik"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="rahul.mulik@me.iitr.ac.in" emp_id="100609">Rahul S. Mulik
                                            </option>
                                            <option value="Raja Chowdhury" dept="Department of Civil Engineering"
                                                email="raja.chowdhury@ce.iitr.ac.in" emp_id="100685">Raja Chowdhury
                                            </option>
                                            <option value="Rajarshi Chakravarti" dept="Department of Earth Sciences"
                                                email="rajarshi.chakravarti@es.iitr.ac.in" emp_id="100930">Rajarshi
                                                Chakravarti</option>
                                            <option value="Rajat Rastogi" dept="Department of Civil Engineering"
                                                email="rajat.rastogi@ce.iitr.ac.in" emp_id="100466">Rajat Rastogi
                                            </option>
                                            <option value="Rajdeep Chatterjee" dept="Department of Physics"
                                                email="rchatterjee@ph.iitr.ac.in" emp_id="100520">Rajdeep Chatterjee
                                            </option>
                                            <option value="Rajesh Kumar" dept="Department of Physics"
                                                email="rajesh.kumar@ph.iitr.ac.in" emp_id="100748">Rajesh Kumar</option>
                                            <option value="Rajesh Srivastava" dept="Department of Physics"
                                                email="rajesh.srivastava@ph.iitr.ac.in" emp_id="100244">Rajesh
                                                Srivastava</option>
                                            <option value="Rajib Chowdhury" dept="Department of Civil Engineering"
                                                email="rajib.chowdhury@ce.iitr.ac.in" emp_id="100589">Rajib Chowdhury
                                            </option>
                                            <option value="Rajib Kumar Panigrahi"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="rajib.panigrahi@ece.iitr.ac.in" emp_id="100599">Rajib Kumar
                                                Panigrahi</option>
                                            <option value="Rakesh Kumar Saunthwal" dept="Department of Chemistry"
                                                email="rakesh.saunthwal@cy.iitr.ac.in" emp_id="101034">Rakesh Kumar
                                                Saunthwal</option>
                                            <option value="Rakesh Ranjan" dept="Department of  Civil Engineering"
                                                email="rakesh.ranjan@ce.iitr.ac.in" emp_id="100983">Rakesh Ranjan
                                            </option>
                                            <option value="Ram Prakash Bharti" dept="Department of Chemical Engineering"
                                                email="rpbharti@ch.iitr.ac.in" emp_id="">Ram Prakash Bharti</option>
                                            <option value="Ram Prakash Bharti" dept="Department of Chemical Engineering"
                                                email="rpbharti@iitr.ac.in" emp_id="100531">Ram Prakash Bharti</option>
                                            <option value="Ram Sateesh Pasupuleti"
                                                dept="Department of Architecture and Planning"
                                                email="ram.pasupuleti@ar.iitr.ac.in" emp_id="100752">Ram Sateesh
                                                Pasupuleti</option>
                                            <option value="Rama Krishna Peddinti" dept="Department of Chemistry"
                                                email="rama.peddinti@cy.iitr.ac.in" emp_id="100407">Rama Krishna
                                                Peddinti</option>
                                            <option value="Ramesh Chandra" dept="Institute Instrumentation Centre (IIC)"
                                                email="ramesh.chandra@ic.iitr.ac.in" emp_id="100411">Ramesh Chandra
                                            </option>
                                            <option value="Ranjana Pathania"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="ranjana.pathania@bt.iitr.ac.in" emp_id="100503">Ranjana Pathania
                                            </option>
                                            <option value="Ravi Kumar"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="ravi@me.iitr.ac.in" emp_id="100122">Ravi Kumar</option>
                                            <option value="Ravi S. Jakka" dept="Department of Earthquake Enggineering"
                                                email="ravi.jakka@eq.iitr.ac.in" emp_id="100556">Ravi S. Jakka</option>
                                            <option value="Ravi Sharma" dept="Department of Earth Sciences"
                                                email="ravi.sharma@es.iitr.ac.in" emp_id="100747">Ravi Sharma</option>
                                            <option value="Ravindra Pandey" dept="Department of Chemistry"
                                                email="rpandey@cy.iitr.ac.in" emp_id="100792">Ravindra Pandey</option>
                                            <option value="Rhythm Singh" dept="Department of Hydro and Renewable Energy"
                                                email="rhythm@hre.iitr.ac.in" emp_id="100816">Rhythm Singh</option>
                                            <option value="Ritu Barthwal"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="ritu.barthwal@bt.iitr.ac.in" emp_id="">Ritu Barthwal</option>
                                            <option value="S. C. Gupta" dept="Department of Earthquake Enggineering"
                                                email="s.gupta@eq.iitr.ac.in" emp_id="100420">S. C. Gupta</option>
                                            <option value="S. P. Harsha"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="s.harsha@me.iitr.ac.in" emp_id="100488">S. P. Harsha</option>
                                            <option value="S.C. Sharma" dept="Department of Paper Technology"
                                                email="subhash.sharma@pt.iitr.ac.in" emp_id="400012">S.C. Sharma
                                            </option>
                                            <option value="S.K. Ghosh" dept="Department of Civil Engineering"
                                                email="sanjay.ghosh@ce.iitr.ac.in" emp_id="100038">S.K. Ghosh</option>
                                            <option value="S.K. Mishra"
                                                dept="Department of Water Resources Development and Management"
                                                email="s.mishra@wr.iitr.ac.in" emp_id="100398">S.K. Mishra</option>
                                            <option value="S.K. Singal" dept="Department of Hydro and Renewable Energy"
                                                email="sunil.singal@hre.iitr.ac.in" emp_id="100364">S.K. Singal</option>
                                            <option value="S.P. Singh" dept="Department of Electrical Engineering"
                                                email="s.singh@ee.iitr.ac.in" emp_id="100085">S.P. Singh</option>
                                            <option value="Sachin Kumar Srivastava" dept="Department of Physics"
                                                email="sachin.srivastava@ph.iitr.ac.in" emp_id="100809">Sachin Kumar
                                                Srivastava</option>
                                            <option value="Sachin Suresh Tiwari"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="sachin.tiwari@bt.iitr.ac.in" emp_id="100977">Sachin Suresh Tiwari
                                            </option>
                                            <option value="Sadhan Ghosh"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="sadhan.ghosh@mt.iitr.ac.in" emp_id="100593">Sadhan Ghosh</option>
                                            <option value="Sagarika Mukhopadhyay" dept="Department of earth sciences"
                                                email="sagarika.mukhopadhyay@es.iitr.ac.in" emp_id="100292">Sagarika
                                                Mukhopadhyay</option>
                                            <option value="Saha Lopamudra" dept="Department of Earth Sciences"
                                                email="saha.lopamudra@es.iitr.ac.in" emp_id="100621">Saha Lopamudra
                                            </option>
                                            <option value="sai ramudu meka"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="s.r.meka@mt.iitr.ac.in" emp_id="100736">sai ramudu meka</option>
                                            <option value="Samadhiya Narendra Kumar"
                                                dept="Department of Civil Engineering"
                                                email="narendra.samadhiya@ce.iitr.ac.in" emp_id="100046">Samadhiya
                                                Narendra Kumar</option>
                                            <option value="Sampat Singh Bhati" dept="Paper Technology"
                                                email="sampat.bhati@pt.iitr.ac.in" emp_id="400158">Sampat Singh Bhati
                                            </option>
                                            <option value="Sandeep bhatt" dept="Earth Sciences"
                                                email="sandeep.bhatt@es.iitr.ac.in" emp_id="100886">Sandeep bhatt
                                            </option>
                                            <option value="Sandeep Singh" dept="Department of Earth Sciences"
                                                email="sandeep.singh@es.iitr.ac.in" emp_id="100304">Sandeep Singh
                                            </option>
                                            <option value="Sanjay Chikermane" dept="Department of Civil Engineering"
                                                email="sanjay.chikermane@ce.iitr.ac.in" emp_id="100648">Sanjay
                                                Chikermane</option>
                                            <option value="Sanjay H Upadhyay"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="sanjay.upadhyay@me.iitr.ac.in" emp_id="100552">Sanjay H Upadhyay
                                            </option>
                                            <option value="Sanjay Palsule"
                                                dept="Department of Polymer and Process Engineering"
                                                email="sanjay.palsule@pe.iitr.ac.in" emp_id="400110">Sanjay Palsule
                                            </option>
                                            <option value="Sanjeev Kumar"
                                                dept="Department of Hydro and Renewable Energy"
                                                email="sanjukec@hre.iitr.ac.in" emp_id="100843">Sanjeev Kumar</option>
                                            <option value="Sanjeev Manhas"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="sanjeev.manhas@ece.iitr.ac.in" emp_id="100522">Sanjeev Manhas
                                            </option>
                                            <option value="Sanjoy Ghosh"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="sanjoy.ghosh@bt.iitr.ac.in" emp_id="100455">Sanjoy Ghosh</option>
                                            <option value="Santanu Pradhan" dept="Centre of Nanotechnology"
                                                email="santanu.pradhan@nt.iitr.ac.in" emp_id="100944">Santanu Pradhan
                                            </option>
                                            <option value="Saptarshi Kolay"
                                                dept="Department of Architecture and Planning"
                                                email="saptarshi.kolay@ar.iitr.ac.in" emp_id="100647">Saptarshi Kolay
                                            </option>
                                            <option value="Sarit Kumar Das" dept="Department of Civil Engineering"
                                                email="sarit.kdas@ce.iitr.ac.in" emp_id="">Sarit Kumar Das</option>
                                            <option value="Satish C Sharma"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="satish.sharma@me.iitr.ac.in" emp_id="100105">Satish C Sharma
                                            </option>
                                            <option value="Satish Chandra" dept="Department of Civil Engineering"
                                                email="satish.chandra@ce.iitr.ac.in" emp_id="100041">Satish Chandra
                                            </option>
                                            <option value="Satyendra Mittal" dept="Department of Civil Engineering"
                                                email="satyendra.mittal@ce.iitr.ac.in" emp_id="100053">Satyendra Mittal
                                            </option>
                                            <option value="Saugata Hazra"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="saugata.hazra@bt.iitr.ac.in" emp_id="100671">Saugata Hazra
                                            </option>
                                            <option value="Saurabh Shiradhonkar"
                                                dept="Department of Earthquake Enggineering"
                                                email="saurabh.shiradhonkar@eq.iitr.ac.in" emp_id="100846">Saurabh
                                                Shiradhonkar</option>
                                            <option value="Saurav Datta"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="saurav.datta@bt.iitr.ac.in" emp_id="100659">Saurav Datta</option>
                                            <option value="Sayanti Chatterjee" dept="Department of Chemistry"
                                                email="sayanti.chatterjee@cy.iitr.ac.in" emp_id="100979">Sayanti
                                                Chatterjee</option>
                                            <option value="Shabina Khanam" dept="Department of Chemical Engineering"
                                                email="shabina.khanam@ch.iitr.ac.in" emp_id="100586">Shabina Khanam
                                            </option>
                                            <option value="Shailesh Ganpule"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="ganpule@me.iitr.ac.in" emp_id="100774">Shailesh Ganpule</option>
                                            <option value="Shailly Tomar"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="shailly.tomar@bt.iitr.ac.in" emp_id="100475">Shailly Tomar
                                            </option>
                                            <option value="Sham Sundar Ravindranath"
                                                dept="Department of Polymer and Process Engineering"
                                                email="sham.ravindranath@pe.iitr.ac.in" emp_id="400142">Sham Sundar
                                                Ravindranath</option>
                                            <option value="Sharmili Das" dept="Department of Electrical Engineering"
                                                email="sharmili.das@ee.iitr.ac.in" emp_id="100533">Sharmili Das</option>
                                            <option value="Shiladitya Sengupta" dept="Department of Physics"
                                                email="shiladityasg@ph.iitr.ac.in" emp_id="100804">Shiladitya Sengupta
                                            </option>
                                            <option value="Shishir Sinha" dept="Department of Chemical Engineering"
                                                email="shishir@ch.iitr.ac.in" emp_id="100467">Shishir Sinha</option>
                                            <option value="Shri Ram Yadav"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="shri.yadav@bt.iitr.ac.in" emp_id="100641">Shri Ram Yadav</option>
                                            <option value="Shubhajit Sadhukhan"
                                                dept="Department of Architecture and Planning"
                                                email="shubhajit@ar.iitr.ac.in" emp_id="100827">Shubhajit Sadhukhan
                                            </option>
                                            <option value="Shubhankar Roy Chowdhury"
                                                dept="Department of Civil Engineering"
                                                email="shubhankar.rc@ce.iitr.ac.in" emp_id="100842">Shubhankar Roy
                                                Chowdhury</option>
                                            <option value="Shushil Kumar" dept="Department of Chemical Engineering"
                                                email="shushil@ch.iitr.ac.in" emp_id="100888">Shushil Kumar</option>
                                            <option value="Siladitya Pal"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="siladitya.pal@me.iitr.ac.in" emp_id="100716">Siladitya Pal
                                            </option>
                                            <option value="Smriti Saraswat"
                                                dept="Department of Architecture and Planning"
                                                email="smriti.saraswat@ar.iitr.ac.in" emp_id="100600">Smriti Saraswat
                                            </option>
                                            <option value="Sneha Singh"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="sneha.singh@me.iitr.ac.in" emp_id="100831">Sneha Singh</option>
                                            <option value="Sohom Chakrabarty"
                                                dept="Department of Electrical Engineering"
                                                email="sohom.chakrabarty@ee.iitr.ac.in" emp_id="100767">Sohom
                                                Chakrabarty</option>
                                            <option value="Soma Rohatgi"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="soma.rohatgi@bt.iitr.ac.in" emp_id="100702">Soma Rohatgi</option>
                                            <option value="Sonal Atreya" dept="Department of Architecture and Planning"
                                                email="sonal.atreya@ar.iitr.ac.in" emp_id="100764">Sonal Atreya</option>
                                            <option value="Sonal K. Thengane "
                                                dept="Department of Hydro and Renewable Energy"
                                                email="sonalt@hre.iitr.ac.in" emp_id="100900">Sonal K. Thengane
                                            </option>
                                            <option value="Sonalisa Ray" dept="Department of Civil Engineering"
                                                email="sonalisa.ray@ce.iitr.ac.in" emp_id="100581">Sonalisa Ray</option>
                                            <option value="Soumitra Satapathi" dept="Department of Physics"
                                                email="soumitra.satapathi@ph.iitr.ac.in" emp_id="100688">Soumitra
                                                Satapathi</option>
                                            <option value="Sourajeet Roy"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="sourajeet.roy@ece.iitr.ac.in" emp_id="100826">Sourajeet Roy
                                            </option>
                                            <option value="Sourav Das"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="sourav.das@mt.iitr.ac.in" emp_id="100737">Sourav Das</option>
                                            <option value="Subudhi Sudhakar"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="sudhakar.subudhi@me.iitr.ac.in" emp_id="100594">Subudhi Sudhakar
                                            </option>
                                            <option value="Sudakshina Dutta" dept="Department of  Civil Engineering"
                                                email="sudakshina@ce.iitr.ac.in" emp_id="100868">Sudakshina Dutta
                                            </option>
                                            <option value="Sudeb Dasgupta"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="sudeb.dasgupta@ece.iitr.ac.in" emp_id="100443">Sudeb Dasgupta
                                            </option>
                                            <option value="Sudheer Kumar Tiwari" dept="Department of Earth Sciences"
                                                email="sudheertiwari07@es.iitr.ac.in" emp_id="100890">Sudheer Kumar
                                                Tiwari</option>
                                            <option value="Sudipta Sarkar" dept="Department of Civil Engineering"
                                                email="sudipta.sarkar@ce.iitr.ac.in" emp_id="100588">Sudipta Sarkar
                                            </option>
                                            <option value="Suhrit Mula"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="suhrit.mula@mt.iitr.ac.in" emp_id="100610">Suhrit Mula</option>
                                            <option value="Sujay Chattopadhyay"
                                                dept="Department of Polymer and Process Engineering"
                                                email="sujay@pe.iitr.ac.in" emp_id="400132">Sujay Chattopadhyay</option>
                                            <option value="Sulakshana P. Mukherjee"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="sulakshana.mukherjee@bt.iitr.ac.in" emp_id="100678">Sulakshana P.
                                                Mukherjee</option>
                                            <option value="Sumana Ghosh" dept="Department of Chemical Engineering"
                                                email="sumana.ghosh@ch.iitr.ac.in" emp_id="100670">Sumana Ghosh</option>
                                            <option value="Sumanta Sarkhel" dept="Department of Physics"
                                                email="sarkhel@ph.iitr.ac.in" emp_id="100683">Sumanta Sarkhel</option>
                                            <option value="Sumeer K. Nath"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="sumeer.nath@mt.iitr.ac.in" emp_id="100184">Sumeer K. Nath
                                            </option>
                                            <option value="Sumeet Mishra"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="sumeet.mishra@mt.iitr.ac.in" emp_id="100912">Sumeet Mishra
                                            </option>
                                            <option value="Sumit Ghatak Choudhuri"
                                                dept="Department of Electrical Engineering" email="sumit@ee.iitr.ac.in"
                                                emp_id="100447">Sumit Ghatak Choudhuri</option>
                                            <option value="Sumit Sen" dept="Department of Hydrology"
                                                email="sumit.sen@hy.iitr.ac.in" emp_id="100582">Sumit Sen</option>
                                            <option value="Sunil Bajpai" dept="Department of Earth Sciences"
                                                email="sunil.bajpai@es.iitr.ac.in" emp_id="100301">Sunil Bajpai</option>
                                            <option value="Sushanta Dutta"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="sushanta@me.iitr.ac.in" emp_id="100513">Sushanta Dutta</option>
                                            <option value="Tapas Kumar Mandal" dept="Department of Chemistry"
                                                email="tapas.mandal@cy.iitr.ac.in" emp_id="100568">Tapas Kumar Mandal
                                            </option>
                                            <option value="Taraknath Das" dept="Department of Chemical Engineering"
                                                email="taraknath.das@ch.iitr.ac.in" emp_id="100705">Taraknath Das
                                            </option>
                                            <option value="Tashi Nautiyal" dept="Department of Physics"
                                                email="tashi.nautiyal@ph.iitr.ac.in" emp_id="100257">Tashi Nautiyal
                                            </option>
                                            <option value="test user" dept="Institute Instrumentation Centre (IIC)"
                                                email="ravisaini.15@gmail.com" emp_id="123453">test user</option>
                                            <option value="TIDES"
                                                dept="Technology Incubation and Entrepreneurship Development Society"
                                                email="ceo_tides@iitr.ac.in" emp_id="123456">TIDES</option>
                                            <option value="Tina Pujara" dept="Department of Architecture and Planning"
                                                email="tina.pujara@ar.iitr.ac.in" emp_id="100510">Tina Pujara</option>
                                            <option value="Tulika Maitra" dept="Department of Physics"
                                                email="tulika.maitra@ph.iitr.ac.in" emp_id="100523">Tulika Maitra
                                            </option>
                                            <option value="U.K. Ghosh"
                                                dept="Department of Polymer and Process Engineering"
                                                email="uttam.ghosh@pe.iitr.ac.in" emp_id="400014">U.K. Ghosh</option>
                                            <option value="U.P. Singh" dept="Department of Chemistry"
                                                email="u.singh@cy.iitr.ac.in" emp_id="100268">U.P. Singh</option>
                                            <option value="Ujjwal Prakash"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="ujjwal.prakash@mt.iitr.ac.in" emp_id="100468">Ujjwal Prakash
                                            </option>
                                            <option value="Umesh Kumar Sharma" dept="Department of Civil Engineering"
                                                email="umesh.sharma@ce.iitr.ac.in" emp_id="100494">Umesh Kumar Sharma
                                            </option>
                                            <option value="Uttam Kumar Roy"
                                                dept="Department of Architecture and Planning"
                                                email="ukroyfap@ar.iitr.ac.in" emp_id="100598">Uttam Kumar Roy</option>
                                            <option value="V Huzur Saran"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="v.saran@me.iitr.ac.in" emp_id="100108">V Huzur Saran</option>
                                            <option value="V. Pruthi"
                                                dept="Department of Biosciences and Bioengineering"
                                                email="v.pruthi@bt.iitr.ac.in" emp_id="">V. Pruthi</option>
                                            <option value="Varun A Baheti"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="varun@mt.iitr.ac.in" emp_id="100873">Varun A Baheti</option>
                                            <option value="Varun Sharma"
                                                dept="Department of Mechanical and Industrial Engineering"
                                                email="varun.sharma@me.iitr.ac.in" emp_id="100797">Varun Sharma</option>
                                            <option value="Venkatesh V" dept="Department of Chemistry"
                                                email="venkatesh.v@cy.iitr.ac.in" emp_id="100855">Venkatesh V</option>
                                            <option value="Vibhore Rastogi" dept="--select--"
                                                email="vibhore.rastogi@pt.iitr.ac.in" emp_id="400155">Vibhore Rastogi
                                            </option>
                                            <option value="Vidit Gaur" dept="Department of Mechanical Engineering"
                                                email="vidit.gaur@me.iitr.ac.in" emp_id="100832">Vidit Gaur</option>
                                            <option value="Vijay Kumar Agarwal"
                                                dept="Department of Chemical Engineering"
                                                email="vijay.agarwal@ch.iitr.ac.in" emp_id="100176">Vijay Kumar Agarwal
                                            </option>
                                            <option value="Vikram V. Dabhade"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="vikram.dabhade@mt.iitr.ac.in" emp_id="100543">Vikram V. Dabhade
                                            </option>
                                            <option value="Vimal Chandra Srivastava"
                                                dept="Department of Chemical Engineering"
                                                email="vimal.srivastava@ch.iitr.ac.in" emp_id="100484">Vimal Chandra
                                                Srivastava</option>
                                            <option value="Vimal Kumar" dept="Department of Chemical Engineering"
                                                email="vimal.kumar@ch.iitr.ac.in" emp_id="100563">Vimal Kumar</option>
                                            <option value="Vinay Kumar Tyagi" dept="Department of Civil Engineering"
                                                email="vinay.tyagi@ce.iitr.ac.in" emp_id="">Vinay Kumar Tyagi</option>
                                            <option value="Vinay Pant" dept="Department of Electrical Engineering"
                                                email="vinay.pant@ee.iitr.ac.in" emp_id="10072">Vinay Pant</option>
                                            <option value="Vinod Pankajakshan"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="vinod.pankajakshan@ece.iitr.ac.in" emp_id="100564">Vinod
                                                Pankajakshan</option>
                                            <option value="Vipul Prakash" dept="Department of Civil Engineering"
                                                email="vipul.prakash@ce.iitr.ac.in" emp_id="100199">Vipul Prakash
                                            </option>
                                            <option value="Vipul Rastogi" dept="Department of Physics"
                                                email="vipul.rastogi@ph.iitr.ac.in" emp_id="100384">Vipul Rastogi
                                            </option>
                                            <option value="Vipul Silwal" dept="Department of Earth Sciences"
                                                email="vipul.silwal@es.iitr.ac.in" emp_id="100840">Vipul Silwal</option>
                                            <option value="Vishal Kumar" dept="Department of Electrical Engineering"
                                                email="vishal.kumar@ee.iitr.ac.in" emp_id="100545">Vishal Kumar</option>
                                            <option value="Vishvendra Singh Poonia"
                                                dept="Department of Electronics and Communication Engineering"
                                                email="vishvendra@ece.iitr.ac.in" emp_id="100803">Vishvendra Singh
                                                Poonia</option>
                                            <option value="Vishwas A Sawant" dept="Department of Civil Engineering"
                                                email="vishwas.sawant@ce.iitr.ac.in" emp_id="100491">Vishwas A Sawant
                                            </option>
                                            <option value="Vivek K. Malik" dept="Department of Physics"
                                                email="vivek.malik@ph.iitr.ac.in" emp_id="100661">Vivek K. Malik
                                            </option>
                                            <option value="Vivek Pancholi"
                                                dept="Department of Metallurgical and Materials Engineering"
                                                email="vivek.pancholi@mt.iitr.ac.in" emp_id="100462">Vivek Pancholi
                                            </option>
                                            <option value="Yadagiri Dongari" dept="Department of Chemistry"
                                                email="yadagiri.dongari@cy.iitr.ac.in" emp_id="100936">Yadagiri Dongari
                                            </option>
                                            <option value="Yogendra Singh" dept="Department of Earthquake Enggineering"
                                                email="yogendra.singh@eq.iitr.ac.in" emp_id="100207">Yogendra Singh
                                            </option>
                                            <option value="Yogesh Kumar Sharma" dept="Department of Physics"
                                                email="yogesh.sharma@ph.iitr.ac.in" emp_id="100733">Yogesh Kumar Sharma
                                            </option>
                                            <option value="Yogesh Vijay Hote"
                                                dept="Department of Electrical Engineering"
                                                email="yogesh.hote@ee.iitr.ac.in" emp_id="100560">Yogesh Vijay Hote
                                            </option>
                                            <option value="Yuvraj Negi"
                                                dept="Department of Polymer and Process Engineering"
                                                email="yuvraj.negi@pe.iitr.ac.in" emp_id="400113">Yuvraj Negi</option>
                                            <option value="Z. Ahmad" dept="Department of Civil Engineering"
                                                email="z.ahmad@ce.iitr.ac.in" emp_id="100065">Z. Ahmad</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Supervisor Department <span class="required">*</span></label>
                                        <input type="text" class="form-control" readonly name="supervisor_dept"
                                            id="supervisor_dept" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Supervisor Email <span class="required">*</span></label>
                                        <input type="email" class="form-control" readonly name="supervisor_email"
                                            id="supervisor_email" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group" style="position:relative">
                                        <label>Supervisor Employee Number <span class="required">*</span></label>
                                        <input type="text" class="form-control" readonly name="supervisor_id"
                                            id="supervisor_id" required>
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="row">
                        <div class="col-md-6 external_educational hide">
                            <div class="form-group">
                                <label>Select User</label> 
                                <select class="form-control" name="user" id="external_user_type">
                                    <option>--select--</option>
                                    <option value='student'>Student</option>
                                    <option value='faculty'>Faculty</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6 external_faculty hide">
                            <div class="form-group">
                                <label>Designation</label>
                                <select name='designation' class='form-control'>
                                    <option value='Ast-prof'>Assistant Professor</option>
                                    <option value='Aso-prof'>Associate Professor</option>
                                    <option value='prof'>Professor</option>
                                </select>
                            </div>
                        </div>
                    </div> -->
                            <div class="address_detail hide">
                                <div class="row">
                                    <!-- <div class="col-md-6">
                                <div class="form-group">
                                    <label>Institute Name</label> 
                                    <input type="text" class="form-control" name='org_name' placeholder="Enter Institute Name">
                                </div>
                            </div> -->
                                    <!-- <div class="col-md-6">
                                <div class="form-group">
                                    <label>District</label> 
                                    <input type="text" class="form-control" name='district' placeholder="Enter District">
                                </div>
                            </div> -->
                                </div>
                                <!-- <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>City</label>
                                    <select class="form-control" name="city_id">
                                        <option>--select--</option>
                                                                                    <option value="1">Nicobars</option>
                                                                                    <option value="2">North And Middle Andaman</option>
                                                                                    <option value="3">South Andaman</option>
                                                                                    <option value="4">Anantapur</option>
                                                                                    <option value="5">Chittoor</option>
                                                                                    <option value="6">East Godavari</option>
                                                                                    <option value="7">Guntur</option>
                                                                                    <option value="8">Krishna</option>
                                                                                    <option value="9">Kurnool</option>
                                                                                    <option value="10">Prakasam</option>
                                                                                    <option value="11">Sri Potti Sri ramulu Nellore</option>
                                                                                    <option value="12">Srikakulam</option>
                                                                                    <option value="13">Visakhapatnam</option>
                                                                                    <option value="14">Vizianagaram</option>
                                                                                    <option value="15">West Godavari</option>
                                                                                    <option value="16">YSR</option>
                                                                                    <option value="17">Along</option>
                                                                                    <option value="18">Anini</option>
                                                                                    <option value="19">Anjaw</option>
                                                                                    <option value="20">Bomdila</option>
                                                                                    <option value="21">Changlang</option>
                                                                                    <option value="22">Daporijo</option>
                                                                                    <option value="23">Dibang Valley</option>
                                                                                    <option value="24">East Kameng</option>
                                                                                    <option value="25">East Siang</option>
                                                                                    <option value="26">Hawai</option>
                                                                                    <option value="27">Jamin</option>
                                                                                    <option value="28">Khonsa</option>
                                                                                    <option value="29">Koloriang</option>
                                                                                    <option value="30">Kurung Kumey</option>
                                                                                    <option value="31">Lohit</option>
                                                                                    <option value="32">Lower Dibang Valley</option>
                                                                                    <option value="33">Lower Subansiri</option>
                                                                                    <option value="34">Papumpare</option>
                                                                                    <option value="35">Pasighat</option>
                                                                                    <option value="36">Roing</option>
                                                                                    <option value="37">Seppa</option>
                                                                                    <option value="38">Tawang</option>
                                                                                    <option value="39">Tawang Town</option>
                                                                                    <option value="40">Tezu</option>
                                                                                    <option value="41">Tirap</option>
                                                                                    <option value="42">Upper Siang</option>
                                                                                    <option value="43">Upper Subansiri</option>
                                                                                    <option value="44">West Kameng</option>
                                                                                    <option value="45">West Siang</option>
                                                                                    <option value="46">Yingkiong</option>
                                                                                    <option value="47">Yupia</option>
                                                                                    <option value="48">Ziro</option>
                                                                                    <option value="49">Amingaon</option>
                                                                                    <option value="50">Baksa</option>
                                                                                    <option value="51">Barpeta</option>
                                                                                    <option value="52">Basugaon</option>
                                                                                    <option value="53">Bongaigaon</option>
                                                                                    <option value="54">Cachar</option>
                                                                                    <option value="55">Chirang</option>
                                                                                    <option value="56">Darrang</option>
                                                                                    <option value="57">Dhemaji</option>
                                                                                    <option value="58">Dhubri</option>
                                                                                    <option value="59">Dibrugarh</option>
                                                                                    <option value="60">Dima Hasao</option>
                                                                                    <option value="61">Diphu</option>
                                                                                    <option value="62">Goalpara</option>
                                                                                    <option value="63">Golaghat</option>
                                                                                    <option value="64">Guwahati</option>
                                                                                    <option value="65">Haflong</option>
                                                                                    <option value="66">Hailakandi</option>
                                                                                    <option value="67">Jorhat</option>
                                                                                    <option value="68">Kamrup</option>
                                                                                    <option value="69">Kamrup Metropolitan</option>
                                                                                    <option value="70">Karbi Anglong</option>
                                                                                    <option value="71">Karimganj</option>
                                                                                    <option value="72">Kokrajhar</option>
                                                                                    <option value="73">Lakhimpur</option>
                                                                                    <option value="74">Mangaldoi</option>
                                                                                    <option value="75">Morigaon</option>
                                                                                    <option value="76">Musalpur</option>
                                                                                    <option value="77">Nagaon</option>
                                                                                    <option value="78">Nalbari</option>
                                                                                    <option value="79">North Lakhimpur</option>
                                                                                    <option value="80">Odalguri</option>
                                                                                    <option value="81">Silchar</option>
                                                                                    <option value="82">Sivasagar</option>
                                                                                    <option value="83">Sonitpur</option>
                                                                                    <option value="84">Tezpur</option>
                                                                                    <option value="85">Tinsukia</option>
                                                                                    <option value="86">Udalguri</option>
                                                                                    <option value="87">Araria</option>
                                                                                    <option value="88">Arwal</option>
                                                                                    <option value="89">Aurangabad</option>
                                                                                    <option value="90">Banka</option>
                                                                                    <option value="91">Begusarai</option>
                                                                                    <option value="92">Bhagalpur</option>
                                                                                    <option value="93">Bhojpur</option>
                                                                                    <option value="94">Buxar</option>
                                                                                    <option value="95">Darbhanga</option>
                                                                                    <option value="96">Gaya</option>
                                                                                    <option value="97">Gopalganj</option>
                                                                                    <option value="98">Jamui</option>
                                                                                    <option value="99">Jehanabad</option>
                                                                                    <option value="100">Kaimur</option>
                                                                                    <option value="101">Katihar</option>
                                                                                    <option value="102">Khagaria</option>
                                                                                    <option value="103">Kishanganj</option>
                                                                                    <option value="104">Lakhisarai</option>
                                                                                    <option value="105">Madhepura</option>
                                                                                    <option value="106">Madhubani</option>
                                                                                    <option value="107">Munger</option>
                                                                                    <option value="108">Muzaffarpur</option>
                                                                                    <option value="109">Nalanda</option>
                                                                                    <option value="110">Nawada</option>
                                                                                    <option value="111">Pashchim Champaran</option>
                                                                                    <option value="112">Patna</option>
                                                                                    <option value="113">Purbi Champaran</option>
                                                                                    <option value="114">Purnia</option>
                                                                                    <option value="115">Rohtas</option>
                                                                                    <option value="116">Saharsa</option>
                                                                                    <option value="117">Samastipur</option>
                                                                                    <option value="118">Saran</option>
                                                                                    <option value="119">Sheikhpura</option>
                                                                                    <option value="120">Sheohar</option>
                                                                                    <option value="121">Sitamarhi</option>
                                                                                    <option value="122">Siwan</option>
                                                                                    <option value="123">Supaul</option>
                                                                                    <option value="124">Vaishali</option>
                                                                                    <option value="125">Chandigarh</option>
                                                                                    <option value="126">Bastar</option>
                                                                                    <option value="127">Bijapur</option>
                                                                                    <option value="128">Bilaspur</option>
                                                                                    <option value="129">Dantewada</option>
                                                                                    <option value="130">Dhamtari</option>
                                                                                    <option value="131">Durg</option>
                                                                                    <option value="132">Janjgir Champa</option>
                                                                                    <option value="133">Jashpur Nagar</option>
                                                                                    <option value="134">Kanker</option>
                                                                                    <option value="135">Kawardha</option>
                                                                                    <option value="136">Korba</option>
                                                                                    <option value="137">Koriya</option>
                                                                                    <option value="138">Mahasamund</option>
                                                                                    <option value="139">Narayanpur</option>
                                                                                    <option value="140">Raigarh</option>
                                                                                    <option value="141">Raipur</option>
                                                                                    <option value="142">Rajnandgaon</option>
                                                                                    <option value="143">Surguja</option>
                                                                                    <option value="144">Dadra and Nagar Haveli</option>
                                                                                    <option value="145">Daman</option>
                                                                                    <option value="146">Diu</option>
                                                                                    <option value="147">Delhi</option>
                                                                                    <option value="148">Ghaziabad</option>
                                                                                    <option value="149">Faridabad</option>
                                                                                    <option value="150">Gurgaon</option>
                                                                                    <option value="151">Noida</option>
                                                                                    <option value="152">North Goa</option>
                                                                                    <option value="153">South Goa</option>
                                                                                    <option value="154">Ahmedabad</option>
                                                                                    <option value="155">Amreli</option>
                                                                                    <option value="156">Anand</option>
                                                                                    <option value="157">Banaskantha</option>
                                                                                    <option value="158">Bharuch</option>
                                                                                    <option value="159">Bhavnagar</option>
                                                                                    <option value="160">Dohad</option>
                                                                                    <option value="161">Gandhinagar</option>
                                                                                    <option value="162">Jamnagar</option>
                                                                                    <option value="163">Junagadh</option>
                                                                                    <option value="164">Kachchh</option>
                                                                                    <option value="165">Kheda</option>
                                                                                    <option value="166">Mahesana</option>
                                                                                    <option value="167">Narmada</option>
                                                                                    <option value="168">Navsari</option>
                                                                                    <option value="169">PanchMahal</option>
                                                                                    <option value="170">Patan</option>
                                                                                    <option value="171">Porbandar</option>
                                                                                    <option value="172">Rajkot</option>
                                                                                    <option value="173">Sabarkantha</option>
                                                                                    <option value="174">Surat</option>
                                                                                    <option value="175">Surendranagar</option>
                                                                                    <option value="176">Tapi</option>
                                                                                    <option value="177">The Dangs</option>
                                                                                    <option value="178">Vadodara</option>
                                                                                    <option value="179">Valsad</option>
                                                                                    <option value="180">Ambala</option>
                                                                                    <option value="181">Bhiwani</option>
                                                                                    <option value="183">Fatehabad</option>
                                                                                    <option value="185">Hisar</option>
                                                                                    <option value="186">Jhajjar</option>
                                                                                    <option value="187">Jind</option>
                                                                                    <option value="188">Kaithal</option>
                                                                                    <option value="189">Karnal</option>
                                                                                    <option value="190">Kurukshetra</option>
                                                                                    <option value="191">Mahendragarh</option>
                                                                                    <option value="192">Mewat</option>
                                                                                    <option value="193">Palwal</option>
                                                                                    <option value="194">Panchkula</option>
                                                                                    <option value="195">Panipat</option>
                                                                                    <option value="196">Rewari</option>
                                                                                    <option value="197">Rohtak</option>
                                                                                    <option value="198">Sirsa</option>
                                                                                    <option value="199">Sonipat</option>
                                                                                    <option value="200">Yamunanagar</option>
                                                                                    <option value="201">Bilaspur</option>
                                                                                    <option value="202">Chamba</option>
                                                                                    <option value="203">Hamirpur</option>
                                                                                    <option value="204">Kangra</option>
                                                                                    <option value="205">Kinnaur</option>
                                                                                    <option value="206">Kullu</option>
                                                                                    <option value="207">Lahul and Spiti</option>
                                                                                    <option value="208">Mandi</option>
                                                                                    <option value="209">Shimla</option>
                                                                                    <option value="210">Sirmaur</option>
                                                                                    <option value="211">Solan</option>
                                                                                    <option value="212">Una</option>
                                                                                    <option value="213">Anantnag</option>
                                                                                    <option value="214">Badgam</option>
                                                                                    <option value="215">Bandipora</option>
                                                                                    <option value="216">Baramulla</option>
                                                                                    <option value="217">Doda</option>
                                                                                    <option value="218">Ganderbal</option>
                                                                                    <option value="219">Jammu</option>
                                                                                    <option value="220">Kargil</option>
                                                                                    <option value="221">Kathua</option>
                                                                                    <option value="222">Kishtwar</option>
                                                                                    <option value="223">Kulgam</option>
                                                                                    <option value="224">Kupwara</option>
                                                                                    <option value="225">Leh</option>
                                                                                    <option value="226">Poonch</option>
                                                                                    <option value="227">Pulwama</option>
                                                                                    <option value="228">Rajouri</option>
                                                                                    <option value="229">Ramban</option>
                                                                                    <option value="230">Reasi</option>
                                                                                    <option value="231">Samba</option>
                                                                                    <option value="232">Shupiyan</option>
                                                                                    <option value="233">Srinagar</option>
                                                                                    <option value="234">Udhampur</option>
                                                                                    <option value="235">Bokaro</option>
                                                                                    <option value="236">Chatra</option>
                                                                                    <option value="237">Deoghar</option>
                                                                                    <option value="238">Dhanbad</option>
                                                                                    <option value="239">Dumka</option>
                                                                                    <option value="240">Garhwa</option>
                                                                                    <option value="241">Giridih</option>
                                                                                    <option value="242">Godda</option>
                                                                                    <option value="243">Gumla</option>
                                                                                    <option value="244">Hazaribagh</option>
                                                                                    <option value="245">Jamshedpur</option>
                                                                                    <option value="246">Jamtara</option>
                                                                                    <option value="247">Khunti</option>
                                                                                    <option value="248">Kodarma</option>
                                                                                    <option value="249">Latehar</option>
                                                                                    <option value="250">Lohardaga</option>
                                                                                    <option value="251">Pakur</option>
                                                                                    <option value="252">Palamu</option>
                                                                                    <option value="253">Pashchimi Singhbhum</option>
                                                                                    <option value="254">Purbi Singhbhum</option>
                                                                                    <option value="255">Ramgarh</option>
                                                                                    <option value="256">Ranchi</option>
                                                                                    <option value="257">Sahibganj</option>
                                                                                    <option value="258">Saraikela Kharsawan</option>
                                                                                    <option value="259">Simdega</option>
                                                                                    <option value="260">Bagalkot</option>
                                                                                    <option value="261">Ballari</option>
                                                                                    <option value="262">Bengaluru</option>
                                                                                    <option value="264">Belgaum</option>
                                                                                    <option value="265">Bidar</option>
                                                                                    <option value="266">Chamarajanagar</option>
                                                                                    <option value="267">Chikballapur</option>
                                                                                    <option value="268">Chikkamagaluru</option>
                                                                                    <option value="269">Chitradurga</option>
                                                                                    <option value="270">Dakshina Kannada</option>
                                                                                    <option value="271">Davanagere</option>
                                                                                    <option value="272">Dharwad</option>
                                                                                    <option value="273">Gadag</option>
                                                                                    <option value="274">Hassan</option>
                                                                                    <option value="275">Haveri</option>
                                                                                    <option value="276">Kalaburagi</option>
                                                                                    <option value="277">Kodagu</option>
                                                                                    <option value="278">Kolar</option>
                                                                                    <option value="279">Koppal</option>
                                                                                    <option value="280">Mandya</option>
                                                                                    <option value="281">Mysore</option>
                                                                                    <option value="282">Raichur</option>
                                                                                    <option value="283">Ramanagara</option>
                                                                                    <option value="284">Shivamogga</option>
                                                                                    <option value="285">Tumakuru</option>
                                                                                    <option value="286">Udupi</option>
                                                                                    <option value="287">Uttara Kannada</option>
                                                                                    <option value="288">Vijayapura</option>
                                                                                    <option value="289">Yadgir</option>
                                                                                    <option value="290">Alappuzha</option>
                                                                                    <option value="291">Ernakulam</option>
                                                                                    <option value="292">Idukki</option>
                                                                                    <option value="293">Kannur</option>
                                                                                    <option value="294">Kasaragod</option>
                                                                                    <option value="295">Kollam</option>
                                                                                    <option value="296">Kottayam</option>
                                                                                    <option value="297">Kozhikode</option>
                                                                                    <option value="298">Malappuram</option>
                                                                                    <option value="299">Palakkad</option>
                                                                                    <option value="300">Pathanamthitta</option>
                                                                                    <option value="301">Thiruvananthapuram</option>
                                                                                    <option value="302">Thrissur</option>
                                                                                    <option value="303">Wayanad</option>
                                                                                    <option value="304">Lakshadweep</option>
                                                                                    <option value="305">Alirajpur</option>
                                                                                    <option value="306">Anuppur</option>
                                                                                    <option value="307">Ashoknagar</option>
                                                                                    <option value="308">Balaghat</option>
                                                                                    <option value="309">Barwani</option>
                                                                                    <option value="310">Betul</option>
                                                                                    <option value="311">Bhind</option>
                                                                                    <option value="312">Bhopal</option>
                                                                                    <option value="313">Burhanpur</option>
                                                                                    <option value="314">Chhattarpur</option>
                                                                                    <option value="315">Chhindwara</option>
                                                                                    <option value="316">Damoh</option>
                                                                                    <option value="317">Datia</option>
                                                                                    <option value="318">Dewas</option>
                                                                                    <option value="319">Dhar</option>
                                                                                    <option value="320">Dindori</option>
                                                                                    <option value="321">Guna</option>
                                                                                    <option value="322">Gwalior</option>
                                                                                    <option value="323">Harda</option>
                                                                                    <option value="324">Hoshangabad</option>
                                                                                    <option value="325">Indore</option>
                                                                                    <option value="326">Jabalpur</option>
                                                                                    <option value="327">Jhabua</option>
                                                                                    <option value="328">Katni</option>
                                                                                    <option value="329">Khandwa</option>
                                                                                    <option value="330">Mandla</option>
                                                                                    <option value="331">Mandsaur</option>
                                                                                    <option value="332">Morena</option>
                                                                                    <option value="333">Narsimhapur</option>
                                                                                    <option value="334">Neemuch</option>
                                                                                    <option value="335">Panna</option>
                                                                                    <option value="336">Raisen</option>
                                                                                    <option value="337">Rajgarh</option>
                                                                                    <option value="338">Ratlam</option>
                                                                                    <option value="339">Rewa</option>
                                                                                    <option value="340">Sagar</option>
                                                                                    <option value="341">Satna</option>
                                                                                    <option value="342">Sehore</option>
                                                                                    <option value="343">Seoni</option>
                                                                                    <option value="344">Shahdol</option>
                                                                                    <option value="345">Shajapur</option>
                                                                                    <option value="346">Sheopur</option>
                                                                                    <option value="347">Shivpuri</option>
                                                                                    <option value="348">Sidhi</option>
                                                                                    <option value="349">Singrauli</option>
                                                                                    <option value="350">Tikamgarh</option>
                                                                                    <option value="351">Ujjain</option>
                                                                                    <option value="352">Umaria</option>
                                                                                    <option value="353">Vidisha</option>
                                                                                    <option value="354">West Nimar</option>
                                                                                    <option value="355">Ahmadnagar</option>
                                                                                    <option value="356">Akola</option>
                                                                                    <option value="357">Amravati</option>
                                                                                    <option value="358">Aurangabad</option>
                                                                                    <option value="359">Beed</option>
                                                                                    <option value="360">Bhandara</option>
                                                                                    <option value="361">Buldana</option>
                                                                                    <option value="362">Chandrapur</option>
                                                                                    <option value="363">Dhule</option>
                                                                                    <option value="364">Gadchiroli</option>
                                                                                    <option value="365">Gondia</option>
                                                                                    <option value="366">Hingoli</option>
                                                                                    <option value="367">Jalgaon</option>
                                                                                    <option value="368">Jalna</option>
                                                                                    <option value="369">Kolhapur</option>
                                                                                    <option value="370">Latur</option>
                                                                                    <option value="371">Mumbai City</option>
                                                                                    <option value="372">Mumbai Suburban</option>
                                                                                    <option value="373">Nagpur</option>
                                                                                    <option value="374">Nanded</option>
                                                                                    <option value="375">Nandurbar</option>
                                                                                    <option value="376">Nashik</option>
                                                                                    <option value="377">Osmanabad</option>
                                                                                    <option value="378">Parbhani</option>
                                                                                    <option value="379">Pune</option>
                                                                                    <option value="380">Raigad</option>
                                                                                    <option value="381">Ratnagiri</option>
                                                                                    <option value="382">Sangli</option>
                                                                                    <option value="383">Satara</option>
                                                                                    <option value="384">Sindhudurg</option>
                                                                                    <option value="385">Solapur</option>
                                                                                    <option value="386">Thane</option>
                                                                                    <option value="387">Wardha</option>
                                                                                    <option value="388">Washim</option>
                                                                                    <option value="389">Yavatmal</option>
                                                                                    <option value="390">Bishnupur</option>
                                                                                    <option value="391">Chandel</option>
                                                                                    <option value="392">Churachandpur</option>
                                                                                    <option value="393">Imphal East</option>
                                                                                    <option value="394">Imphal West</option>
                                                                                    <option value="395">Lamphelpat</option>
                                                                                    <option value="396">Porompat</option>
                                                                                    <option value="397">Senapati</option>
                                                                                    <option value="398">Tamenglong</option>
                                                                                    <option value="399">Thoubal</option>
                                                                                    <option value="400">Ukhrul</option>
                                                                                    <option value="401">Baghmara</option>
                                                                                    <option value="402">Cherrapunjee</option>
                                                                                    <option value="403">East Garo Hills</option>
                                                                                    <option value="404">East Khasi Hills</option>
                                                                                    <option value="405">Jaintia Hills</option>
                                                                                    <option value="406">Jowai</option>
                                                                                    <option value="407">Lawsohtun</option>
                                                                                    <option value="408">Madanriting</option>
                                                                                    <option value="409">Mairang</option>
                                                                                    <option value="410">Mawlai</option>
                                                                                    <option value="411">Mawpat</option>
                                                                                    <option value="412">Nongkseh</option>
                                                                                    <option value="413">Nongmynsong</option>
                                                                                    <option value="414">Nongstoin</option>
                                                                                    <option value="415">Nongthymmai</option>
                                                                                    <option value="416">Pynthormukhrah</option>
                                                                                    <option value="417">Resubelpara</option>
                                                                                    <option value="418">Ri Bhoi</option>
                                                                                    <option value="419">Shillong</option>
                                                                                    <option value="420">Shillong Cantonment</option>
                                                                                    <option value="421">South Garo Hills</option>
                                                                                    <option value="422">Tura</option>
                                                                                    <option value="423">Umlyngka</option>
                                                                                    <option value="424">Umpling</option>
                                                                                    <option value="425">Umroi</option>
                                                                                    <option value="426">West Garo Hills</option>
                                                                                    <option value="427">West Khasi Hills</option>
                                                                                    <option value="428">Williamnagar</option>
                                                                                    <option value="429">Aizawl</option>
                                                                                    <option value="430">Champhai</option>
                                                                                    <option value="431">Kolasib</option>
                                                                                    <option value="432">Lawngtlai</option>
                                                                                    <option value="433">Lunglei</option>
                                                                                    <option value="434">Mamit</option>
                                                                                    <option value="435">Saiha</option>
                                                                                    <option value="436">Serchhip</option>
                                                                                    <option value="437">Dimapur</option>
                                                                                    <option value="438">Kiphire</option>
                                                                                    <option value="439">Kohima</option>
                                                                                    <option value="440">Longleng</option>
                                                                                    <option value="441">Mokokchung</option>
                                                                                    <option value="442">Mon</option>
                                                                                    <option value="443">Peren</option>
                                                                                    <option value="444">Phek</option>
                                                                                    <option value="445">Tuensang</option>
                                                                                    <option value="446">Wokha</option>
                                                                                    <option value="447">Zunheboto</option>
                                                                                    <option value="448">Anugul</option>
                                                                                    <option value="449">Balangir</option>
                                                                                    <option value="450">Balasore</option>
                                                                                    <option value="451">Bargarh</option>
                                                                                    <option value="452">Bhadrak</option>
                                                                                    <option value="453">Bhubaneswar</option>
                                                                                    <option value="454">Boudh</option>
                                                                                    <option value="455">Cuttack</option>
                                                                                    <option value="456">Deogarh</option>
                                                                                    <option value="457">Dhenkanal</option>
                                                                                    <option value="458">Gajapati</option>
                                                                                    <option value="459">Ganjam</option>
                                                                                    <option value="460">Jagatsinghpur</option>
                                                                                    <option value="461">Jajpur</option>
                                                                                    <option value="462">Jharsuguda</option>
                                                                                    <option value="463">Kalahandi</option>
                                                                                    <option value="464">Kandhamal</option>
                                                                                    <option value="465">Kendrapara</option>
                                                                                    <option value="466">Keonjhar</option>
                                                                                    <option value="467">Khordha</option>
                                                                                    <option value="468">Koraput</option>
                                                                                    <option value="469">Malkangiri</option>
                                                                                    <option value="470">Mayurbhanj</option>
                                                                                    <option value="471">Nabarangapur</option>
                                                                                    <option value="472">Nayagarh</option>
                                                                                    <option value="473">Nuapada</option>
                                                                                    <option value="474">Puri</option>
                                                                                    <option value="475">Rayagada</option>
                                                                                    <option value="476">Sambalpur</option>
                                                                                    <option value="477">Subarnapur</option>
                                                                                    <option value="478">Sundargarh</option>
                                                                                    <option value="479">Karaikal</option>
                                                                                    <option value="480">Mahe</option>
                                                                                    <option value="481">Puducherry</option>
                                                                                    <option value="482">Yanam</option>
                                                                                    <option value="483">Amritsar</option>
                                                                                    <option value="484">Barnala</option>
                                                                                    <option value="485">Bathinda</option>
                                                                                    <option value="486">Faridkot</option>
                                                                                    <option value="487">Fatehgarh Sahib</option>
                                                                                    <option value="488">Ferozepur</option>
                                                                                    <option value="489">Gurdaspur</option>
                                                                                    <option value="490">Hoshiarpur</option>
                                                                                    <option value="491">Jalandhar</option>
                                                                                    <option value="492">Kapurthala</option>
                                                                                    <option value="493">Ludhiana</option>
                                                                                    <option value="494">Mansa</option>
                                                                                    <option value="495">Moga</option>
                                                                                    <option value="496">Mohali</option>
                                                                                    <option value="497">Muktsar</option>
                                                                                    <option value="498">Patiala</option>
                                                                                    <option value="499">Rupnagar</option>
                                                                                    <option value="500">Sangrur</option>
                                                                                    <option value="501">Shahid Bhagat Singh Nagar</option>
                                                                                    <option value="502">Tarn Taran</option>
                                                                                    <option value="503">Ajmer</option>
                                                                                    <option value="504">Alwar</option>
                                                                                    <option value="505">Banswara</option>
                                                                                    <option value="506">Baran</option>
                                                                                    <option value="507">Barmer</option>
                                                                                    <option value="508">Bharatpur</option>
                                                                                    <option value="509">Bhilwara</option>
                                                                                    <option value="510">Bikaner</option>
                                                                                    <option value="511">Bundi</option>
                                                                                    <option value="512">Chittaurgarh</option>
                                                                                    <option value="513">Churu</option>
                                                                                    <option value="514">Dausa</option>
                                                                                    <option value="515">Dholpur</option>
                                                                                    <option value="516">Dungarpur</option>
                                                                                    <option value="517">Ganganagar</option>
                                                                                    <option value="518">Hanumangarh</option>
                                                                                    <option value="519">Jaipur</option>
                                                                                    <option value="520">Jaisalmer</option>
                                                                                    <option value="521">Jalore</option>
                                                                                    <option value="522">Jhalawar</option>
                                                                                    <option value="523">Jhunjhunu</option>
                                                                                    <option value="524">Jodhpur</option>
                                                                                    <option value="525">Karauli</option>
                                                                                    <option value="526">Kota</option>
                                                                                    <option value="527">Nagaur</option>
                                                                                    <option value="528">Pali</option>
                                                                                    <option value="529">Pratapgarh</option>
                                                                                    <option value="530">Rajsamand</option>
                                                                                    <option value="531">Sawai Madhopur</option>
                                                                                    <option value="532">Sikar</option>
                                                                                    <option value="533">Sirohi</option>
                                                                                    <option value="534">Tonk</option>
                                                                                    <option value="535">Udaipur</option>
                                                                                    <option value="536">East Sikkim</option>
                                                                                    <option value="537">Gangtok</option>
                                                                                    <option value="538">Geyzing</option>
                                                                                    <option value="539">Mangam</option>
                                                                                    <option value="540">Namchi</option>
                                                                                    <option value="541">North Sikkim</option>
                                                                                    <option value="542">South Sikkim</option>
                                                                                    <option value="543">West Sikkim</option>
                                                                                    <option value="544">Ariyalur</option>
                                                                                    <option value="545">Chennai</option>
                                                                                    <option value="546">Coimbatore</option>
                                                                                    <option value="547">Cuddalore</option>
                                                                                    <option value="548">Dharmapuri</option>
                                                                                    <option value="549">Dindigul</option>
                                                                                    <option value="550">Erode</option>
                                                                                    <option value="551">Kanchipuram</option>
                                                                                    <option value="552">Kanyakumari</option>
                                                                                    <option value="553">Karur</option>
                                                                                    <option value="554">Krishnagiri</option>
                                                                                    <option value="555">Madurai</option>
                                                                                    <option value="556">Nagapattinam</option>
                                                                                    <option value="557">Namakkal</option>
                                                                                    <option value="558">Perambalur</option>
                                                                                    <option value="559">Pudukkottai</option>
                                                                                    <option value="560">Ramanathapuram</option>
                                                                                    <option value="561">Salem</option>
                                                                                    <option value="562">Sivaganga</option>
                                                                                    <option value="563">Thanjavur</option>
                                                                                    <option value="564">The Nilgiris</option>
                                                                                    <option value="565">Theni</option>
                                                                                    <option value="566">Thiruvallur</option>
                                                                                    <option value="567">Thiruvarur</option>
                                                                                    <option value="568">Thoothukkudi</option>
                                                                                    <option value="569">Tiruchirappalli</option>
                                                                                    <option value="570">Tirunelveli</option>
                                                                                    <option value="571">Tiruppur</option>
                                                                                    <option value="572">Tiruvannamalai</option>
                                                                                    <option value="573">Vellore</option>
                                                                                    <option value="574">Viluppuram</option>
                                                                                    <option value="575">Virudhunagar</option>
                                                                                    <option value="576">Adilabad</option>
                                                                                    <option value="577">Hyderabad</option>
                                                                                    <option value="578">Karimnagar</option>
                                                                                    <option value="579">Khammam</option>
                                                                                    <option value="580">Mahbubnagar</option>
                                                                                    <option value="581">Medak</option>
                                                                                    <option value="582">Nalgonda</option>
                                                                                    <option value="583">Nizamabad</option>
                                                                                    <option value="584">Rangareddy</option>
                                                                                    <option value="585">Sangrareddy</option>
                                                                                    <option value="586">Warangal</option>
                                                                                    <option value="587">Agartala</option>
                                                                                    <option value="588">Ambassa</option>
                                                                                    <option value="589">Dhalai</option>
                                                                                    <option value="590">Gomati</option>
                                                                                    <option value="591">Kailashahar</option>
                                                                                    <option value="592">Khowai</option>
                                                                                    <option value="593">North Tripura</option>
                                                                                    <option value="594">Sipahijala</option>
                                                                                    <option value="595">South Tripura</option>
                                                                                    <option value="596">West Tripura</option>
                                                                                    <option value="597">Agra</option>
                                                                                    <option value="598">Aligarh</option>
                                                                                    <option value="599">Allahabad</option>
                                                                                    <option value="600">Ambedkar Nagar</option>
                                                                                    <option value="601">Auraiya</option>
                                                                                    <option value="602">Azamgarh</option>
                                                                                    <option value="603">Baghpat</option>
                                                                                    <option value="604">Bahraich</option>
                                                                                    <option value="605">Ballia</option>
                                                                                    <option value="606">Balrampur</option>
                                                                                    <option value="607">Banda</option>
                                                                                    <option value="608">Barabanki</option>
                                                                                    <option value="609">Bareilly</option>
                                                                                    <option value="610">Basti</option>
                                                                                    <option value="611">Bijnor</option>
                                                                                    <option value="612">Budaun</option>
                                                                                    <option value="613">Bulandshahar</option>
                                                                                    <option value="614">Chandauli</option>
                                                                                    <option value="615">Chitrakoot</option>
                                                                                    <option value="616">Deoria</option>
                                                                                    <option value="617">Etah</option>
                                                                                    <option value="618">Etawah</option>
                                                                                    <option value="619">Faizabad</option>
                                                                                    <option value="620">Farrukhabad</option>
                                                                                    <option value="621">Fatehpur</option>
                                                                                    <option value="622">Firozabad</option>
                                                                                    <option value="624">Ghazipur</option>
                                                                                    <option value="625">Gonda</option>
                                                                                    <option value="626">Gorakhpur</option>
                                                                                    <option value="627">Hamirpur</option>
                                                                                    <option value="628">Hapur</option>
                                                                                    <option value="629">Hardoi</option>
                                                                                    <option value="630">Hathras</option>
                                                                                    <option value="631">Jalaun</option>
                                                                                    <option value="632">Jaunpur</option>
                                                                                    <option value="633">Jhansi</option>
                                                                                    <option value="634">Jyotiba Phule Nagar</option>
                                                                                    <option value="635">Kannauj</option>
                                                                                    <option value="636">Kanpur Nagar</option>
                                                                                    <option value="637">Kanshiram Nagar</option>
                                                                                    <option value="638">Kaushambi</option>
                                                                                    <option value="639">Kushinagar</option>
                                                                                    <option value="640">Lakhimpur Kheri</option>
                                                                                    <option value="641">Lalitpur</option>
                                                                                    <option value="642">Lucknow</option>
                                                                                    <option value="643">Maharajganj</option>
                                                                                    <option value="644">Mahoba</option>
                                                                                    <option value="645">Mainpuri</option>
                                                                                    <option value="646">Mathura</option>
                                                                                    <option value="647">Mau</option>
                                                                                    <option value="648">Meerut</option>
                                                                                    <option value="649">Mirzapur</option>
                                                                                    <option value="650">Moradabad</option>
                                                                                    <option value="651">Muzaffarnagar</option>
                                                                                    <option value="653">Pilibhit</option>
                                                                                    <option value="654">Pratapgarh</option>
                                                                                    <option value="655">Rae Bareli</option>
                                                                                    <option value="656">Ramabai Nagar</option>
                                                                                    <option value="657">Rampur</option>
                                                                                    <option value="658">Saharanpur</option>
                                                                                    <option value="659">sambhal</option>
                                                                                    <option value="660">Sant Kabir Nagar</option>
                                                                                    <option value="661">Sant Ravidas Nagar</option>
                                                                                    <option value="662">Shahjahanpur</option>
                                                                                    <option value="663">Shrawasti</option>
                                                                                    <option value="664">Siddharth Nagar</option>
                                                                                    <option value="665">Sitapur</option>
                                                                                    <option value="666">Sonbhadra</option>
                                                                                    <option value="667">Sultanpur</option>
                                                                                    <option value="668">Unnao</option>
                                                                                    <option value="669">Varanasi</option>
                                                                                    <option value="670">Almora</option>
                                                                                    <option value="671">Bageshwar</option>
                                                                                    <option value="672">Chamoli</option>
                                                                                    <option value="673">Champawat</option>
                                                                                    <option value="674">Dehradun</option>
                                                                                    <option value="675">Haridwar</option>
                                                                                    <option value="676">Nainital</option>
                                                                                    <option value="677">Pauri Garhwal</option>
                                                                                    <option value="678">Pithoragarh</option>
                                                                                    <option value="679">Rudraprayag</option>
                                                                                    <option value="680">Tehri Garhwal</option>
                                                                                    <option value="681">Udham Singh Nagar</option>
                                                                                    <option value="682">Uttarkashi</option>
                                                                                    <option value="683">Asansol</option>
                                                                                    <option value="684">Bankura</option>
                                                                                    <option value="685">Barddhaman</option>
                                                                                    <option value="686">Birbhum</option>
                                                                                    <option value="687">Dakshin Dinajpur</option>
                                                                                    <option value="688">Darjiling</option>
                                                                                    <option value="689">Durgapur</option>
                                                                                    <option value="690">Haora</option>
                                                                                    <option value="691">Howrah</option>
                                                                                    <option value="692">Hugli</option>
                                                                                    <option value="693">Jalpaiguri</option>
                                                                                    <option value="694">Koch Bihar</option>
                                                                                    <option value="695">Kolkata</option>
                                                                                    <option value="696">Malda</option>
                                                                                    <option value="697">Murshidabad</option>
                                                                                    <option value="698">Nadia</option>
                                                                                    <option value="699">North Twenty Four Parganas</option>
                                                                                    <option value="700">Paschim Medinipur</option>
                                                                                    <option value="701">Purba Medinipur</option>
                                                                                    <option value="702">Purulia</option>
                                                                                    <option value="703">South Twenty Four Parganas</option>
                                                                                    <option value="704">Uttar Dinajpur</option>
                                                                                    <option value="705">Belthangady</option>
                                                                                    <option value="706">Roorkee</option>
                                                                                    <option value="707">Bahadurgarh</option>
                                                                                    <option value="709">Pithampur</option>
                                                                                    <option value="710">Bhiwandi</option>
                                                                                    <option value="711">Achampet</option>
                                                                                    <option value="712">Warangal</option>
                                                                                    <option value="713">Zirakpur</option>
                                                                                    <option value="714">Kharar</option>
                                                                                    <option value="715">Gulbarga</option>
                                                                                    <option value="716">Bhiwadi</option>
                                                                                    <option value="717">Bengaluru Rural</option>
                                                                                    <option value="718">CUDDAPAH</option>
                                                                            </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>State</label>
                                    <select class="form-control" name="state_id">
                                        <option>--select--</option>
                                                                                    <option value="1">Uttar Pradesh</option>
                                                                                    <option value="2">Delhi NCR</option>
                                                                                    <option value="3">Haryana</option>
                                                                                    <option value="4">Punjab</option>
                                                                                    <option value="5">Himachal Pradesh</option>
                                                                                    <option value="6">Uttarakhand</option>
                                                                                    <option value="7">Assam</option>
                                                                                    <option value="8">Arunachal Pradesh</option>
                                                                                    <option value="9">Meghalaya</option>
                                                                                    <option value="10">Sikkim</option>
                                                                                    <option value="11">Mizoram</option>
                                                                                    <option value="12">Manipur</option>
                                                                                    <option value="13">Nagaland</option>
                                                                                    <option value="14">Tripura</option>
                                                                                    <option value="15">Gujarat</option>
                                                                                    <option value="16">Rajasthan</option>
                                                                                    <option value="17">Madhya Pradesh</option>
                                                                                    <option value="18">Goa</option>
                                                                                    <option value="19">Jammu Kashmir</option>
                                                                                    <option value="20">Kerala</option>
                                                                                    <option value="21">Tamil Nadu</option>
                                                                                    <option value="22">Karnataka</option>
                                                                                    <option value="23">Telangana</option>
                                                                                    <option value="24">Andhra Pradesh</option>
                                                                                    <option value="25">Maharashtra</option>
                                                                                    <option value="26">Chhattisgarh</option>
                                                                                    <option value="27">Orissa</option>
                                                                                    <option value="28">West Bengal</option>
                                                                                    <option value="29">Jharkhand</option>
                                                                                    <option value="30">Bihar</option>
                                                                                    <option value="31">Andaman and Nicobar Islands</option>
                                                                                    <option value="32">Chandigarh</option>
                                                                                    <option value="33">Dadra and Nagar Haveli</option>
                                                                                    <option value="34">Daman and Diu</option>
                                                                                    <option value="35">Lakshadweep</option>
                                                                                    <option value="36">Puducherry</option>
                                                                            </select>
                                </div>
                            </div>
                        </div> -->
                            </div>
                            <!-- <div class='gover_rnd hide' id='gover_rnd'>                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Do you have MOU with IIT Roorkee</label>
                                    <input type="checkbox" class="form-control" name="mou_check">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>MOU Copy</label>
                                    <input type='file' class="form-control" name='mou_path'>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>MOU Validity</label>
                                    <input type='date' class="form-control" name='mou_validity'>
                                </div>
                            </div>
                        </div>
                    </div> -->
                            <button class="btn btn-sm btn-primary float-right m-t-n-xs" type="submit"
                                id="student_submit">
                                <strong>Submit</strong></button>
                        </form>

                    </div>
                </div>
            </div>
            <!-- /.card -->
        </div>

        <script type="text/javascript">
            $('#external_user_type').change(function () {
        var external_user_type = $(this).val();
        if (external_user_type == 'faculty') {
            $('.external_faculty').removeClass('hide');
            $('.registration_detail').addClass('hide');
        } else if (external_user_type == 'student') {
            $('.registration_detail').removeClass('hide');
            $('.external_faculty').addClass('hide');
        }
    });
    
    $('#student_program_id').change(function(e) {
        e.preventDefault();
        if ($(this).val() == 'Others') {
            $('.program_other').show();
        } else {
            $('.program_other').hide();
        }
    });
        

    $('#supervisor_name').on('change', function () {
        var incharge_id = $(this).find(':selected').attr('emp_id');
        var incharge_email = $(this).find(':selected').attr('email');
        var incharge_dept = $(this).find(':selected').attr('dept');
        $('#supervisor_id').val(incharge_id);
        $('#supervisor_email').val(incharge_email);
        $('#supervisor_dept').val(incharge_dept);
    });

    $('#user_type').change(function () {
        var userType = $(this).val();
        if (userType == 2) {
            $('.supervisor_Section').removeClass('hide');
            $('.emp_detail').removeClass('hide');
            $('.registration_detail').removeClass('hide');
            $('.iitr_student').removeClass('hide');
            $('.external_faculty').addClass('hide');
            $('.institute_section').addClass('hide');
            $('.address_detail').addClass('hide');
            $('.gover_rnd').addClass('hide');
            $('.external_educational').addClass('hide');
        } else if (userType == 3) {
            $('.institute_section').removeClass('hide');
            $('.emp_detail').removeClass('hide');
            $('.registration_detail').addClass('hide');
            $('.supervisor_Section').addClass('hide');
            $('.iitr_student').addClass('hide');
            $('.external_faculty').addClass('hide');
            $('.address_detail').addClass('hide');
            $('.gover_rnd').addClass('hide');
            $('.external_educational').addClass('hide');
        } else if (userType == 4) {
            $('.institute_section').removeClass('hide');
            $('.emp_detail').removeClass('hide');
            $('.registration_detail').addClass('hide');
            $('.supervisor_Section').addClass('hide');
            $('.iitr_student').addClass('hide');
            $('.external_educational').removeClass('hide');
            $('.address_detail').removeClass('hide');
            $('.external_faculty').addClass('hide');
            $('.gover_rnd').addClass('hide');
        } else if (userType == 5) {
            $('.institute_section').removeClass('hide');
            $('.gover_rnd').removeClass('hide');
            $('.address_detail').removeClass('hide');
            $('.external_faculty').removeClass('hide');
            $('.external_educational').addClass('hide');
            $('.supervisor_Section').addClass('hide');
            $('.iitr_student').addClass('hide');
            $('.emp_detail').addClass('hide');
            $('.registration_detail').addClass('hide');
        } else if (userType == 6) {
            $('.institute_section').removeClass('hide');
            $('.external_faculty').removeClass('hide');
            $('.address_detail').removeClass('hide');
            $('.gover_rnd').addClass('hide');
            $('.external_educational').addClass('hide');
            $('.supervisor_Section').addClass('hide');
            $('.iitr_student').addClass('hide');
            $('.emp_detail').addClass('hide');
            $('.registration_detail').addClass('hide');
        } else {
            $('.institute_section').removeClass('hide');
            $('.external_faculty').addClass('hide');
            $('.supervisor_Section').addClass('hide');
            $('.address_detail').addClass('hide');
            $('.gover_rnd').addClass('hide');
            $('.external_educational').addClass('hide');
            $('.iitr_student').addClass('hide');
            $('.emp_detail').addClass('hide');
            $('.registration_detail').addClass('hide');
        }
    });

    $('document').ready(function () {
        var userType = $('#user_type').val();
        if (userType == 2) {
            $('.institute_section').addClass('hide');
            $('.emp_detail').removeClass('hide');
            $('.registration_detail').removeClass('hide');
            $('.iitr_student').removeClass('hide');
            $('.external_faculty').addClass('hide');
            $('.address_detail').addClass('hide');
            $('.gover_rnd').addClass('hide');
            $('.external_educational').addClass('hide');
        } else if (userType == 3) {
            $('.institute_section').removeClass('hide');
            $('.emp_detail').removeClass('hide');
            $('.registration_detail').addClass('hide');
            $('.iitr_student').addClass('hide');
            $('.external_faculty').addClass('hide');
            $('.address_detail').addClass('hide');
            $('.gover_rnd').addClass('hide');
            $('.external_educational').addClass('hide');
        } else if (userType == 4) {
            $('.institute_section').removeClass('hide');
            $('.emp_detail').removeClass('hide');
            $('.registration_detail').addClass('hide');
            $('.iitr_student').addClass('hide');
            $('.external_educational').removeClass('hide');
            $('.address_detail').removeClass('hide');
            $('.gover_rnd').addClass('hide');
            var external_user_type = $('#external_user_type').val();
            if (external_user_type == 'faculty') {
                $('.external_faculty').removeClass('hide');
                $('.registration_detail').addClass('hide');
            } else if (external_user_type == 'student') {
                $('.registration_detail').removeClass('hide');
                $('.external_faculty').addClass('hide');
            }
        } else if (userType == 5) {
            $('.institute_section').removeClass('hide');
            $('.gover_rnd').removeClass('hide');
            $('.address_detail').removeClass('hide');
            $('.external_faculty').removeClass('hide');
            $('.external_educational').addClass('hide');
            $('.iitr_student').addClass('hide');
            $('.emp_detail').addClass('hide');
            $('.registration_detail').addClass('hide');
        } else if (userType == 6) {
            $('.institute_section').removeClass('hide');
            $('.external_faculty').removeClass('hide');
            $('.address_detail').removeClass('hide');
            $('.gover_rnd').addClass('hide');
            $('.external_educational').addClass('hide');
            $('.iitr_student').addClass('hide');
            $('.emp_detail').addClass('hide');
            $('.registration_detail').addClass('hide');
        } else {
            $('.institute_section').removeClass('hide');
            $('.external_faculty').addClass('hide');
            $('.address_detail').addClass('hide');
            $('.gover_rnd').addClass('hide');
            $('.external_educational').addClass('hide');
            $('.iitr_student').addClass('hide');
            $('.emp_detail').addClass('hide');
            $('.registration_detail').addClass('hide');
        }
    });
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
        </script>

        <!--        <div class="footer">
            <div>
                <strong>Copyright</strong> IITR-EMS &copy; 2024            </div>
        </div>-->
    </div>
    </div>

    <!-- Mainly scripts -->
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/popper.min.js"></script>
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/bootstrap.js"></script>
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Flot -->
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/flot/jquery.flot.js"></script>
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/flot/jquery.flot.spline.js"></script>
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/flot/jquery.flot.symbol.js"></script>
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/flot/jquery.flot.time.js"></script>

    <!-- Peity -->
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/peity/jquery.peity.min.js"></script>
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/demo/peity-demo.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/inspinia.js"></script>
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/pace/pace.min.js"></script>

    <!-- jQuery UI -->
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/jquery-ui/jquery-ui.min.js"></script>

    <!-- Jvectormap -->
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js">
    </script>
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js">
    </script>

    <!-- EayPIE -->
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/easypiechart/jquery.easypiechart.js"></script>

    <!-- Sparkline -->
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/sparkline/jquery.sparkline.min.js"></script>

    <!-- Sparkline demo data  -->
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/demo/sparkline-demo.js"></script>

    <!-- data table -->
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/dataTables/dataTables.bootstrap4.min.js"></script>

    <!-- Toastr script -->
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/toastr/toastr.min.js"></script>

    <!-- Switchery -->
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/switchery/switchery.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9/dist/sweetalert2.min.js"></script>

    <!-- DROPZONE -->
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/dropzone/dropzone.js"></script>
    <!-- checkbox -->
    <script src="https://iicbooking.iitr.ac.in/admin_asset/js/plugins/iCheck/icheck.min.js"></script>
</body>

</html>